export type Phase = "menu" | "play" | "scare" | "pause" | "dead" | "win";

export type PartInfo = {
  id: string;
  name: string;
  where: string;
  got: boolean;
};

export type HudState = {
  phase: Phase;
  battery: number;
  stamina: number;
  parts: PartInfo[];
  prompt: string;
  objective: string;
  elapsed: number;
  best: number | null;
  deaths: number;
  threat: number;
  sound: boolean;
  ready: boolean;
};

export type TouchInput = {
  moveX: number;
  moveY: number;
  lookX: number;
  lookY: number;
  sprint: boolean;
  interact: boolean;
};

export const SAVE_KEY = "jinlu-save-v1";

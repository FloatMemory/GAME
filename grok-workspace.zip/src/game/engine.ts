import * as THREE from "three";
import { getSfx, type Sfx } from "@/game/audio";
import { createLevel, type ItemDef, type Level, type Wall } from "@/game/level";
import { SAVE_KEY, type HudState, type PartInfo, type Phase, type TouchInput } from "@/game/types";

const EYE = 1.64;
const PLAYER_R = 0.36;
const MONSTER_R = 0.46;
const WALK = 3.45;
const SPRINT = 6.55;
const CATCH = 1.12;
const WORLD_UP = new THREE.Vector3(0, 1, 0);

type Save = { v: 1; best: number | null; deaths: number };

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

function resolve(x: number, z: number, radius: number, level: Level) {
  let px = x;
  let pz = z;
  const circles = level.trees;
  for (let pass = 0; pass < 2; pass++) {
    for (let i = 0; i < circles.length; i++) {
      const t = circles[i];
      const dx = px - t.x;
      const dz = pz - t.z;
      const min = radius + t.r;
      const d2 = dx * dx + dz * dz;
      if (d2 >= min * min) continue;
      if (d2 > 1e-8) {
        const d = Math.sqrt(d2);
        const s = (min - d) / d;
        px += dx * s;
        pz += dz * s;
      } else px += min;
    }
    for (let i = 0; i < level.rocks.length; i++) {
      const t = level.rocks[i];
      const dx = px - t.x;
      const dz = pz - t.z;
      const min = radius + t.r;
      const d2 = dx * dx + dz * dz;
      if (d2 >= min * min) continue;
      if (d2 > 1e-8) {
        const d = Math.sqrt(d2);
        const s = (min - d) / d;
        px += dx * s;
        pz += dz * s;
      } else px += min;
    }
    {
      const dx = px - level.bike.x;
      const dz = pz - level.bike.z;
      const min = radius + 0.8;
      const d2 = dx * dx + dz * dz;
      if (d2 < min * min) {
        if (d2 > 1e-8) {
          const d = Math.sqrt(d2);
          const s = (min - d) / d;
          px += dx * s;
          pz += dz * s;
        } else px += min;
      }
    }
    const walls = level.walls;
    for (let i = 0; i < walls.length; i++) {
      const w = walls[i];
      const cx = clamp(px, w.minX, w.maxX);
      const cz = clamp(pz, w.minZ, w.maxZ);
      const dx = px - cx;
      const dz = pz - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 >= radius * radius) continue;
      if (d2 > 1e-6) {
        const d = Math.sqrt(d2);
        const s = (radius - d) / d;
        px += dx * s;
        pz += dz * s;
      } else {
        const left = px - w.minX;
        const right = w.maxX - px;
        const down = pz - w.minZ;
        const up = w.maxZ - pz;
        const m = Math.min(left, right, down, up);
        if (m === left) px = w.minX - radius;
        else if (m === right) px = w.maxX + radius;
        else if (m === down) pz = w.minZ - radius;
        else pz = w.maxZ + radius;
      }
    }
    px = clamp(px, -76, 76);
    pz = clamp(pz, -76, 76);
  }
  return { x: px, z: pz };
}

function losBlocked(x0: number, z0: number, x1: number, z1: number, walls: Wall[]) {
  const dx = x1 - x0;
  const dz = z1 - z0;
  for (let i = 0; i < walls.length; i++) {
    const w = walls[i];
    let t0 = 0;
    let t1 = 1;
    const planes: [number, number][] = [
      [-dx, x0 - w.minX],
      [dx, w.maxX - x0],
      [-dz, z0 - w.minZ],
      [dz, w.maxZ - z0],
    ];
    let hit = true;
    for (let p = 0; p < 4; p++) {
      const denom = planes[p][0];
      const numer = planes[p][1];
      if (Math.abs(denom) < 1e-8) {
        if (numer < 0) {
          hit = false;
          break;
        }
      } else {
        const t = numer / denom;
        if (denom < 0) {
          if (t > t1) {
            hit = false;
            break;
          }
          if (t > t0) t0 = t;
        } else {
          if (t < t0) {
            hit = false;
            break;
          }
          if (t < t1) t1 = t;
        }
      }
    }
    if (hit && t1 >= t0) return true;
  }
  return false;
}

type MonsterRig = {
  group: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  mouth: THREE.Mesh;
  head: THREE.Group;
};

function buildMonster(): MonsterRig {
  const group = new THREE.Group();
  const skin = new THREE.MeshStandardMaterial({
    color: 0xc8c2b8,
    roughness: 0.72,
    metalness: 0.02,
    emissive: 0x2a1412,
    emissiveIntensity: 0.45,
  });
  const dark = new THREE.MeshStandardMaterial({ color: 0x120c0c, roughness: 1 });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.26, 0.72, 4, 8), skin);
  torso.position.y = 1.28;
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 0.28, 8), skin);
  neck.position.y = 1.82;
  const headPivot = new THREE.Group();
  headPivot.position.y = 2.05;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 12, 10), skin);
  head.scale.set(0.78, 1.22, 0.86);
  const pitGeo = new THREE.SphereGeometry(0.035, 8, 6);
  const pitL = new THREE.Mesh(pitGeo, dark);
  pitL.position.set(-0.07, 0.02, 0.14);
  const pitR = new THREE.Mesh(pitGeo, dark);
  pitR.position.set(0.07, 0.02, 0.14);
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.16, 0.04), dark);
  mouth.position.set(0, -0.08, 0.15);
  headPivot.add(head, pitL, pitR, mouth);
  const armL = new THREE.Group();
  armL.position.set(-0.32, 1.62, 0);
  const armR = new THREE.Group();
  armR.position.set(0.32, 1.62, 0);
  const armGeo = new THREE.CapsuleGeometry(0.055, 0.95, 3, 6);
  const aL = new THREE.Mesh(armGeo, skin);
  aL.position.y = -0.55;
  const aR = new THREE.Mesh(armGeo, skin);
  aR.position.y = -0.55;
  armL.add(aL);
  armR.add(aR);
  const legL = new THREE.Group();
  legL.position.set(-0.12, 0.86, 0);
  const legR = new THREE.Group();
  legR.position.set(0.12, 0.86, 0);
  const legGeo = new THREE.CapsuleGeometry(0.07, 0.7, 3, 6);
  const lL = new THREE.Mesh(legGeo, skin);
  lL.position.y = -0.42;
  const lR = new THREE.Mesh(legGeo, skin);
  lR.position.y = -0.42;
  legL.add(lL);
  legR.add(lR);
  group.add(torso, neck, headPivot, armL, armR, legL, legR);
  return { group, armL, armR, legL, legR, mouth, head: headPivot };
}

function buildTorch() {
  const g = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({
    color: 0x2a2c28,
    roughness: 0.4,
    metalness: 0.6,
  });
  const geo = new THREE.CylinderGeometry(0.042, 0.05, 0.28, 8);
  geo.rotateX(-Math.PI / 2);
  const body = new THREE.Mesh(geo, bodyMat);
  const headGeo = new THREE.CylinderGeometry(0.07, 0.048, 0.09, 8);
  headGeo.rotateX(-Math.PI / 2);
  const head = new THREE.Mesh(headGeo, bodyMat);
  head.position.z = -0.17;
  const lens = new THREE.Mesh(
    new THREE.CircleGeometry(0.055, 12),
    new THREE.MeshBasicMaterial({ color: 0xfff1c8 }),
  );
  lens.position.z = -0.216;
  const arm = new THREE.Mesh(
    new THREE.BoxGeometry(0.09, 0.09, 0.34),
    new THREE.MeshStandardMaterial({ color: 0x3a2a22, roughness: 0.85 }),
  );
  arm.position.set(0.04, -0.08, 0.16);
  g.add(body, head, lens, arm);
  return g;
}

function itemMesh(def: ItemDef) {
  const g = new THREE.Group();
  const glow = (color: number, em: number, emI: number) =>
    new THREE.MeshStandardMaterial({
      color,
      roughness: 0.45,
      metalness: 0.35,
      emissive: em,
      emissiveIntensity: emI,
    });
  if (def.kind === "spark") {
    const m = glow(0xd0d4d8, 0x665533, 0.55);
    const mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.22, 8), m);
    mesh.position.y = 0.28;
    g.add(mesh);
    return { g, mats: [m] };
  }
  if (def.kind === "oil") {
    const m = glow(0xc6a23a, 0x665010, 0.45);
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.28, 0.14), m);
    mesh.position.y = 0.22;
    g.add(mesh);
    return { g, mats: [m] };
  }
  if (def.kind === "pack") {
    const m = glow(0x242628, 0x441010, 0.4);
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.2, 0.18), m);
    mesh.position.y = 0.18;
    const cap = new THREE.Mesh(
      new THREE.BoxGeometry(0.08, 0.06, 0.06),
      new THREE.MeshStandardMaterial({ color: 0x8f1d1d, roughness: 0.5, emissive: 0x8f1d1d, emissiveIntensity: 0.4 }),
    );
    cap.position.set(0, 0.3, 0);
    g.add(mesh, cap);
    return { g, mats: [m] };
  }
  if (def.kind === "tire") {
    const m = glow(0x1a1a1a, 0x222222, 0.25);
    const mesh = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.08, 8, 14), m);
    mesh.position.y = 0.32;
    g.add(mesh);
    return { g, mats: [m] };
  }
  const m = glow(0xd4c07a, 0x886622, 0.9);
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.16, 8), m);
  mesh.position.y = 0.16;
  g.add(mesh);
  return { g, mats: [m] };
}

export class ForestGame {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private yaw = new THREE.Group();
  private pitch = new THREE.Group();
  private spot: THREE.SpotLight;
  private torch: THREE.Group;
  private timer = new THREE.Timer();
  private level: Level;
  private monster: MonsterRig;
  private sfx: Sfx;
  private keys = new Set<string>();
  private injected: Set<string> | null = null;
  private lookX = 0;
  private lookY = 0;
  private x = 0;
  private z = 0;
  private vx = 0;
  private vz = 0;
  private mx = 0;
  private mz = 0;
  private actualSpeed = 0;
  private phase: Phase = "menu";
  private battery = 1;
  private stamina = 1;
  private sprintLock = false;
  private sprinting = false;
  private elapsed = 0;
  private darkT = 0;
  private bob = 0;
  private stepAcc = 0;
  private threat = 0;
  private scareLeft = 0;
  private walkT = 0;
  private best: number | null = null;
  private deaths = 0;
  private sound = true;
  private prompt = "";
  private objective = "";
  private collected = new Set<string>();
  private itemRoots = new Map<string, THREE.Group>();
  private glows: THREE.MeshStandardMaterial[] = [];
  private wasLocked = false;
  private prevInteract = false;
  private interactQueued = false;
  private disposed = false;
  private clockT = 0;
  touchUi = false;
  private readonly _fwd = new THREE.Vector3();
  private readonly _right = new THREE.Vector3();
  private readonly _cam = new THREE.Vector3();
  private lastEmit = "";
  private onResize: () => void;
  private onKeyDown: (e: KeyboardEvent) => void;
  private onKeyUp: (e: KeyboardEvent) => void;
  private onBlur: () => void;
  private onLock: () => void;
  private onPointerDown: (e: PointerEvent) => void;
  private onPointerMove: (e: PointerEvent) => void;
  private onVis: () => void;

  constructor(
    private canvas: HTMLCanvasElement,
    private touch: TouchInput,
    private onHud: (hud: HudState) => void,
  ) {
    this.level = createLevel();
    this.sfx = getSfx();
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: "high-performance",
      alpha: false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.78;
    this.renderer.setClearColor(0x07090b, 1);
    const dpr = Math.min(window.devicePixelRatio || 1, window.innerWidth < 800 ? 1.25 : 1.6);
    this.renderer.setPixelRatio(dpr);

    this.scene.fog = new THREE.FogExp2(0x07090b, 0.02);
    this.scene.add(new THREE.AmbientLight(0x10141a, 0.22));
    this.scene.add(new THREE.HemisphereLight(0x243440, 0x0a0c08, 0.38));
    const moon = new THREE.DirectionalLight(0x9bb0c4, 0.48);
    moon.position.set(28, 36, -18);
    this.scene.add(moon);
    const moonDisc = new THREE.Mesh(
      new THREE.SphereGeometry(3.2, 16, 12),
      new THREE.MeshBasicMaterial({ color: 0xd5dde6, fog: false }),
    );
    moonDisc.position.set(32, 28, -46);
    this.scene.add(moonDisc);

    this.camera = new THREE.PerspectiveCamera(72, 1, 0.08, 150);
    this.pitch.add(this.camera);
    this.yaw.add(this.pitch);
    this.scene.add(this.yaw);

    this.spot = new THREE.SpotLight(0xfff2d4, 36, 26, 0.5, 0.58, 1.5);
    this.spot.position.set(0.18, -0.12, 0.02);
    this.camera.add(this.spot);
    this.spot.target.position.set(0, -0.04, -1);
    this.camera.add(this.spot.target);

    this.torch = buildTorch();
    this.torch.position.set(0.32, -0.3, -0.46);
    this.camera.add(this.torch);

    this.buildWorld();
    this.monster = buildMonster();
    this.scene.add(this.monster.group);
    this.load();
    this.resetWorld();

    this.timer.connect(document);
    this.onResize = () => this.resize();
    this.onKeyDown = (e) => {
      if (e.code === "Escape") {
        e.preventDefault();
        if (this.phase === "play") this.setPhase("pause");
        else if (this.phase === "pause") this.resume();
        return;
      }
      this.keys.add(e.code);
    };
    this.onKeyUp = (e) => this.keys.delete(e.code);
    this.onBlur = () => this.keys.clear();
    this.onLock = () => {
      const locked = document.pointerLockElement === this.canvas;
      if (!locked && this.wasLocked && this.phase === "play") this.setPhase("pause");
      this.wasLocked = locked;
    };
    this.onPointerDown = (e) => {
      if (this.phase !== "play") return;
      if (document.pointerLockElement !== this.canvas && !this.touchUi) {
        this.requestLock();
        return;
      }
      if (e.button === 0) this.interactQueued = true;
    };
    this.onPointerMove = (e) => {
      if (document.pointerLockElement !== this.canvas) return;
      this.lookX += e.movementX;
      this.lookY += e.movementY;
    };
    this.onVis = () => {
      if (document.visibilityState === "visible") this.sfx.resume();
    };
    window.addEventListener("resize", this.onResize);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    document.addEventListener("pointerlockchange", this.onLock);
    document.addEventListener("visibilitychange", this.onVis);
    canvas.addEventListener("pointerdown", this.onPointerDown);
    canvas.addEventListener("pointermove", this.onPointerMove);
    canvas.addEventListener("contextmenu", (e) => e.preventDefault());
    this.resize();
    this.renderer.setAnimationLoop(() => this.frame());
    this.attachProbe();
    this.emit(true);
  }

  start() {
    this.emit(true);
  }

  begin() {
    this.sfx.unlock();
    if (this.phase !== "pause") this.resetWorld();
    this.setPhase("play");
    this.requestLock();
  }

  resume() {
    this.sfx.unlock();
    this.setPhase("play");
    this.requestLock();
  }

  setSound(on: boolean) {
    this.sound = on;
    this.sfx.setVolume(on ? 0.8 : 0);
    this.emit(true);
  }

  dispose() {
    this.disposed = true;
    this.renderer.setAnimationLoop(null);
    this.timer.disconnect();
    window.removeEventListener("resize", this.onResize);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("pointerlockchange", this.onLock);
    document.removeEventListener("visibilitychange", this.onVis);
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    this.canvas.removeEventListener("pointermove", this.onPointerMove);
    if (window.__controlsTest) delete window.__controlsTest;
    this.renderer.dispose();
  }

  private setPhase(p: Phase) {
    this.phase = p;
    if (p !== "play" && p !== "scare" && document.pointerLockElement === this.canvas) {
      document.exitPointerLock();
    }
    if (p !== "play") {
      this.keys.clear();
      this.vx = 0;
      this.vz = 0;
    }
    this.emit(true);
  }

  private requestLock() {
    if (this.touchUi) return;
    const canvas = this.canvas as HTMLCanvasElement & {
      requestPointerLock: (o?: { unadjustedMovement?: boolean }) => Promise<void> | void;
    };
    try {
      const ret = canvas.requestPointerLock({ unadjustedMovement: true });
      if (ret && typeof (ret as Promise<void>).catch === "function") {
        void (ret as Promise<void>).catch(() => {
          try {
            canvas.requestPointerLock();
          } catch {
            /* ignore */
          }
        });
      }
    } catch {
      try {
        canvas.requestPointerLock();
      } catch {
        /* ignore */
      }
    }
  }

  private resize() {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / Math.max(1, h);
    this.camera.updateProjectionMatrix();
  }

  private frame() {
    if (this.disposed) return;
    this.timer.update();
    const dt = Math.min(this.timer.getDelta(), 0.05);
    this.clockT += dt;
    this.applyLook();
    if (this.phase === "play") {
      this.elapsed += dt;
      this.readMove(dt);
      this.battery = Math.max(0, this.battery - dt * 0.02);
      this.updateMonster(dt);
      this.tickWorld(dt);
      this.tickAudio();
      this.updatePrompt();
    } else if (this.phase === "scare") {
      this.scareLeft -= dt;
      this.poseScare();
      if (this.scareLeft <= 0) this.setPhase("dead");
    }
    this.updateLight();
    this.renderer.render(this.scene, this.camera);
    this.emit(false);
  }

  // FPS basis: yaw object's -Z is forward = (-sin yaw, 0, -cos yaw) when rotation.y = yaw.
  // Mouse: rotation.y -= movementX (right look turns right). A/D strafe, they do not yaw.
  // A = -right, D = +right, W = +forward, S = -forward. Pitch is not applied to movement.
  private applyLook() {
    const sens = 0.00215;
    this.yaw.rotation.y -= (this.lookX + this.touch.lookX) * sens;
    this.pitch.rotation.x -= (this.lookY + this.touch.lookY) * sens;
    const lim = Math.PI / 2 - 0.08;
    this.pitch.rotation.x = clamp(this.pitch.rotation.x, -lim, lim);
    this.lookX = 0;
    this.lookY = 0;
    this.touch.lookX = 0;
    this.touch.lookY = 0;
  }

  private held() {
    return this.injected ?? this.keys;
  }

  private basis() {
    this.yaw.getWorldDirection(this._fwd);
    // Object3D direction is local +Z. The camera looks down -Z, so negate.
    this._fwd.negate();
    this._fwd.y = 0;
    if (this._fwd.lengthSq() < 1e-6) this._fwd.set(0, 0, -1);
    else this._fwd.normalize();
    this._right.crossVectors(this._fwd, WORLD_UP);
    if (this._right.lengthSq() < 1e-6) this._right.set(1, 0, 0);
    else this._right.normalize();
  }

  private readMove(dt: number) {
    const held = this.held();
    let ix = 0;
    let iz = 0;
    if (held.has("KeyD") || held.has("ArrowRight")) ix += 1;
    if (held.has("KeyA") || held.has("ArrowLeft")) ix -= 1;
    if (held.has("KeyW") || held.has("ArrowUp")) iz += 1;
    if (held.has("KeyS") || held.has("ArrowDown")) iz -= 1;
    ix += this.touch.moveX;
    iz += this.touch.moveY;
    const ilen = Math.hypot(ix, iz);
    if (ilen > 1) {
      ix /= ilen;
      iz /= ilen;
    }
    this.basis();
    const wishX = this._right.x * ix + this._fwd.x * iz;
    const wishZ = this._right.z * ix + this._fwd.z * iz;
    const moving = ilen > 0.08;
    const wantSprint =
      moving &&
      iz > 0.25 &&
      (held.has("ShiftLeft") || held.has("ShiftRight") || this.touch.sprint);
    let speed = WALK;
    this.sprinting = false;
    if (wantSprint && !this.sprintLock && this.stamina > 0) {
      speed = SPRINT;
      this.sprinting = true;
      this.stamina = Math.max(0, this.stamina - dt / 5.2);
      if (this.stamina <= 0) this.sprintLock = true;
    } else {
      this.stamina = Math.min(1, this.stamina + dt / 3.6);
      if (this.stamina > 0.32) this.sprintLock = false;
    }
    const targetX = wishX * (moving ? speed : 0);
    const targetZ = wishZ * (moving ? speed : 0);
    const blend = 1 - Math.exp(-dt * 16);
    this.vx += (targetX - this.vx) * blend;
    this.vz += (targetZ - this.vz) * blend;
    const ox = this.x;
    const oz = this.z;
    const dist = Math.hypot(this.vx, this.vz) * dt;
    const n = clamp(Math.ceil(dist / 0.22), 1, 5);
    const h = dt / n;
    for (let i = 0; i < n; i++) {
      const next = resolve(this.x + this.vx * h, this.z + this.vz * h, PLAYER_R, this.level);
      this.x = next.x;
      this.z = next.z;
    }
    this.yaw.position.x = this.x;
    this.yaw.position.z = this.z;
    this.actualSpeed = dt > 0 ? Math.hypot(this.x - ox, this.z - oz) / dt : 0;
    if (this.actualSpeed > 0.45) {
      this.stepAcc += this.actualSpeed * dt;
      const stride = this.sprinting ? 2.15 : 1.65;
      if (this.stepAcc > stride) {
        this.stepAcc = 0;
        this.sfx.step();
      }
    }
    const bobOn = this.actualSpeed > 0.5 ? 1 : 0;
    this.bob += this.actualSpeed * dt;
    this.pitch.position.y = Math.sin(this.bob * 8.2) * 0.04 * bobOn;
    this.torch.position.y = -0.3 + Math.sin(this.bob * 8.2 + 0.4) * 0.018 * bobOn;

    const eEdge = (held.has("KeyE") || held.has("KeyF")) && !this.prevInteract;
    this.prevInteract = held.has("KeyE") || held.has("KeyF") || this.touch.interact;
    if (eEdge || (this.touch.interact && !this.prevTouchInteract) || this.interactQueued) {
      this.tryInteract();
    }
    this.prevTouchInteract = this.touch.interact;
    this.interactQueued = false;
    if (this.touch.interact) {
      /* consumed as level, not a pulse — edge is prevTouchInteract */
    }
  }

  private prevTouchInteract = false;

  private tryInteract() {
    let best: ItemDef | null = null;
    let bestD = 1.85;
    for (const it of this.level.items) {
      if (this.collected.has(it.id)) continue;
      const d = Math.hypot(this.x - it.x, this.z - it.z);
      if (d < bestD) {
        bestD = d;
        best = it;
      }
    }
    if (best) {
      this.collected.add(best.id);
      const root = this.itemRoots.get(best.id);
      if (root) root.visible = false;
      if (!best.part) this.battery = Math.min(1, this.battery + 0.38);
      if (this.battery > 0.05) this.darkT = 0;
      this.sfx.pickup();
      this.updatePrompt();
      this.emit(true);
      return;
    }
    const bd = Math.hypot(this.x - this.level.bike.x, this.z - this.level.bike.z);
    if (bd < 2.35 && this.partsLeft() === 0) {
      if (this.best == null || this.elapsed < this.best) this.best = this.elapsed;
      this.save();
      this.sfx.engine();
      this.setPhase("win");
    }
  }

  private partsLeft() {
    let n = 0;
    for (const it of this.level.items) if (it.part && !this.collected.has(it.id)) n++;
    return n;
  }

  private updateMonster(dt: number) {
    const got = 4 - this.partsLeft();
    let speed = 4.65;
    if (got >= 2) speed += 0.4;
    if (got >= 3) speed += 0.35;
    if (got >= 4) speed += 0.45;
    if (this.battery <= 0) speed += 0.65;
    let dx = this.x - this.mx;
    let dz = this.z - this.mz;
    const dist = Math.hypot(dx, dz) || 1;
    dx /= dist;
    dz /= dist;
    let ax = 0;
    let az = 0;
    const trees = this.level.trees;
    for (let i = 0; i < trees.length; i++) {
      const t = trees[i];
      const ox = this.mx - t.x;
      const oz = this.mz - t.z;
      const d = Math.hypot(ox, oz);
      const min = t.r + 1.15;
      if (d < min && d > 0.001) {
        const k = (min - d) / min;
        ax += (ox / d) * k;
        az += (oz / d) * k;
      }
    }
    dx += ax * 1.8;
    dz += az * 1.8;
    const l2 = Math.hypot(dx, dz) || 1;
    dx /= l2;
    dz /= l2;
    const next = resolve(this.mx + dx * speed * dt, this.mz + dz * speed * dt, MONSTER_R, this.level);
    this.mx = next.x;
    this.mz = next.z;
    if (this.battery <= 0) {
      this.darkT += dt;
      if (this.darkT > 16 && dist > 14) {
        this.basis();
        const wx = this.x - this._fwd.x * 11;
        const wz = this.z - this._fwd.z * 11;
        const p = resolve(wx, wz, MONSTER_R, this.level);
        this.mx = p.x;
        this.mz = p.z;
        this.darkT = 7;
      }
    } else this.darkT = 0;

    const nd = Math.hypot(this.x - this.mx, this.z - this.mz);
    this.threat = clamp(1 - (nd - CATCH) / 16, 0, 1);
    this.monster.group.position.set(this.mx, 0, this.mz);
    this.monster.group.rotation.y = Math.atan2(this.x - this.mx, this.z - this.mz);
    this.walkT += dt * speed;
    const swing = Math.sin(this.walkT * 3.1);
    this.monster.legL.rotation.x = swing * 0.7;
    this.monster.legR.rotation.x = -swing * 0.7;
    this.monster.armL.rotation.x = -swing * 0.55;
    this.monster.armR.rotation.x = swing * 0.55;
    this.monster.head.rotation.z = Math.sin(this.walkT * 1.3) * 0.08;
    this.monster.head.rotation.x = 0.12;
    const open = nd < 4 ? 1.8 : 1;
    this.monster.mouth.scale.set(1, open, 1);

    if (nd < CATCH && !losBlocked(this.x, this.z, this.mx, this.mz, this.level.walls)) {
      this.startScare();
    }
  }

  private startScare() {
    if (this.phase !== "play") return;
    this.phase = "scare";
    this.scareLeft = 0.7;
    this.threat = 1;
    this.deaths += 1;
    this.save();
    this.sfx.death();
    this.poseScare();
    this.emit(true);
  }

  private poseScare() {
    this.camera.getWorldPosition(this._cam);
    this.camera.getWorldDirection(this._fwd);
    const px = this._cam.x + this._fwd.x * 0.95;
    const pz = this._cam.z + this._fwd.z * 0.95;
    this.monster.group.position.set(px, -0.42, pz);
    this.monster.group.rotation.y = Math.atan2(this._cam.x - px, this._cam.z - pz);
    this.monster.mouth.scale.set(1.4, 2.6, 1.3);
    this.monster.head.rotation.x = 0.35;
    this.monster.armL.rotation.x = -1.2;
    this.monster.armR.rotation.x = -1.15;
    const s = Math.sin(this.clockT * 28) * 0.02;
    this.pitch.position.x = s;
    this.pitch.position.y = Math.cos(this.clockT * 23) * 0.02;
  }

  private tickWorld(dt: number) {
    for (const root of this.itemRoots.values()) {
      if (!root.visible) continue;
      root.rotation.y += dt * 0.8;
    }
    const pulse = 0.45 + Math.sin(this.clockT * 3) * 0.25;
    for (const m of this.glows) m.emissiveIntensity = pulse;
  }

  private tickAudio() {
    const dx = this.mx - this.x;
    const dz = this.mz - this.z;
    const dist = Math.hypot(dx, dz);
    if (dist > 30) return;
    this.basis();
    const len = dist || 1;
    const pan = clamp((dx * this._right.x + dz * this._right.z) / len, -1, 1);
    const k = 1 - dist / 30;
    this.sfx.breath(pan, k);
    if (dist < 10) this.sfx.heart(pan, 1 - dist / 10);
  }

  private updatePrompt() {
    const verb = this.touchUi ? "点按拾取" : "按 E 拾取";
    let prompt = "";
    let best = 1.85;
    let name = "";
    for (const it of this.level.items) {
      if (this.collected.has(it.id)) continue;
      const d = Math.hypot(this.x - it.x, this.z - it.z);
      if (d < best) {
        best = d;
        name = it.name;
      }
    }
    if (name) prompt = `${verb} ${name}`;
    else if (Math.hypot(this.x - this.level.bike.x, this.z - this.level.bike.z) < 2.35) {
      prompt = this.partsLeft() === 0 ? (this.touchUi ? "点按发动" : "按 E 发动") : "零件还没齐";
    }
    this.prompt = prompt;
    const left: string[] = [];
    for (const it of this.level.items) {
      if (it.part && !this.collected.has(it.id)) left.push(`${it.where}·${it.name}`);
    }
    this.objective = left.length ? left.join("   ") : "沿路回到摩托车";
  }

  private updateLight() {
    let flick = 1;
    if (this.battery <= 0) flick = 0.015;
    else if (this.battery < 0.22) {
      flick = 0.55 + Math.sin(this.clockT * 34) * 0.2;
      if (Math.sin(this.clockT * 71) > 0.82) flick *= 0.25;
    }
    if (this.phase === "scare") flick = 1.35;
    this.spot.intensity = 34 * flick * (0.35 + 0.65 * clamp(this.battery, 0, 1));
    if (this.phase !== "scare") {
      this.pitch.position.x = 0;
    }
  }

  private resetWorld() {
    this.x = this.level.spawn.x;
    this.z = this.level.spawn.z;
    this.vx = 0;
    this.vz = 0;
    this.yaw.position.set(this.x, EYE, this.z);
    this.yaw.rotation.y = 0;
    this.pitch.rotation.x = 0;
    this.pitch.position.set(0, 0, 0);
    this.mx = this.level.monster.x;
    this.mz = this.level.monster.z;
    this.monster.group.position.set(this.mx, 0, this.mz);
    this.battery = 1;
    this.stamina = 1;
    this.sprintLock = false;
    this.elapsed = 0;
    this.darkT = 0;
    this.threat = 0;
    this.collected.clear();
    for (const root of this.itemRoots.values()) root.visible = true;
    this.actualSpeed = 0;
    this.updatePrompt();
  }

  private load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      const s = JSON.parse(raw) as Save;
      if (!s || s.v !== 1) return;
      this.best = typeof s.best === "number" ? s.best : null;
      this.deaths = typeof s.deaths === "number" ? s.deaths : 0;
    } catch {
      /* ignore broken save */
    }
  }

  private save() {
    const data: Save = { v: 1, best: this.best, deaths: this.deaths };
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    } catch {
      /* ignore quota */
    }
  }

  private partInfos(): PartInfo[] {
    const out: PartInfo[] = [];
    for (const it of this.level.items) {
      if (!it.part) continue;
      out.push({ id: it.id, name: it.name, where: it.where, got: this.collected.has(it.id) });
    }
    return out;
  }

  private emit(force: boolean) {
    const parts = this.partInfos();
    const sig = [
      this.phase,
      this.prompt,
      this.objective,
      Math.round(this.battery * 40),
      Math.round(this.stamina * 20),
      Math.round(this.threat * 20),
      Math.floor(this.elapsed),
      this.best ?? "-",
      this.deaths,
      this.sound ? 1 : 0,
      parts.map((p) => (p.got ? "1" : "0")).join(""),
    ].join("|");
    if (!force && sig === this.lastEmit) return;
    this.lastEmit = sig;
    this.onHud({
      phase: this.phase,
      battery: this.battery,
      stamina: this.stamina,
      parts,
      prompt: this.prompt,
      objective: this.objective,
      elapsed: this.elapsed,
      best: this.best,
      deaths: this.deaths,
      threat: this.phase === "scare" ? 1 : this.threat,
      sound: this.sound,
      ready: true,
    });
  }

  private attachProbe() {
    const dev = import.meta.env.DEV || new URLSearchParams(location.search).has("qa");
    if (!dev) return;
    window.__controlsTest = {
      getYaw: () => this.yaw.rotation.y,
      getSpeed: () => this.actualSpeed,
      getPos: () => ({ x: this.x, y: EYE, z: this.z }),
      setKeys: (codes: string[]) => {
        this.injected = codes.length ? new Set(codes) : null;
      },
      setYaw: (y: number) => {
        this.yaw.rotation.y = y;
      },
      teleport: (x: number, z: number) => {
        const p = resolve(x, z, PLAYER_R, this.level);
        this.x = p.x;
        this.z = p.z;
        this.yaw.position.x = p.x;
        this.yaw.position.z = p.z;
      },
      collectAll: () => {
        for (const it of this.level.items) {
          if (!it.part) continue;
          this.collected.add(it.id);
          const root = this.itemRoots.get(it.id);
          if (root) root.visible = false;
        }
        this.updatePrompt();
        this.emit(true);
      },
    };
  }

  private buildWorld() {
    const tex = this.paintGround();
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(164, 164),
      new THREE.MeshStandardMaterial({ map: tex, roughness: 1, metalness: 0 }),
    );
    ground.geometry.rotateX(-Math.PI / 2);
    this.scene.add(ground);

    const roadMat = new THREE.MeshStandardMaterial({ color: 0x3a3228, roughness: 1 });
    const road = this.level.road;
    for (let i = 0; i < road.length - 1; i++) {
      const ax = road[i][0];
      const az = road[i][1];
      const bx = road[i + 1][0];
      const bz = road[i + 1][1];
      const dx = bx - ax;
      const dz = bz - az;
      const len = Math.hypot(dx, dz);
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(3.5, 0.04, len), roadMat);
      mesh.position.set((ax + bx) / 2, 0.03, (az + bz) / 2);
      mesh.rotation.y = Math.atan2(dx, dz);
      this.scene.add(mesh);
    }

    const ravine = new THREE.Mesh(
      new THREE.BoxGeometry(36, 0.05, 9),
      new THREE.MeshStandardMaterial({ color: 0x101418, roughness: 1 }),
    );
    ravine.position.set(12, 0.045, -49);
    this.scene.add(ravine);
    const plankMat = new THREE.MeshStandardMaterial({ color: 0x5a4632, roughness: 0.9 });
    for (let i = 0; i < 7; i++) {
      const plank = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.06, 7.2), plankMat);
      plank.position.set(4 + i * 1.5, 0.08, -49);
      if (i === 3 || i === 5) plank.rotation.y = 0.4;
      this.scene.add(plank);
    }

    const byColor = new Map<number, THREE.MeshStandardMaterial>();
    const matFor = (color: number) => {
      let m = byColor.get(color);
      if (!m) {
        m = new THREE.MeshStandardMaterial({ color, roughness: 0.92, metalness: 0.02 });
        byColor.set(color, m);
      }
      return m;
    };
    for (const w of this.level.walls) {
      const sx = Math.max(0.05, w.maxX - w.minX);
      const sz = Math.max(0.05, w.maxZ - w.minZ);
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(sx, w.h, sz), matFor(w.color));
      mesh.position.set((w.minX + w.maxX) / 2, w.h / 2, (w.minZ + w.maxZ) / 2);
      this.scene.add(mesh);
    }
    const roof = (x: number, z: number, sx: number, sz: number, y: number, color: number) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(sx, 0.16, sz), matFor(color));
      mesh.position.set(x, y, z);
      this.scene.add(mesh);
    };
    roof(11, 2, 7, 5.6, 2.78, 0x3e3c38);
    roof(-14, -12, 6.2, 5.4, 2.52, 0x2a1c12);

    const rockMat = new THREE.MeshStandardMaterial({ color: 0x2a2926, roughness: 1 });
    for (const rk of this.level.rocks) {
      const mesh = new THREE.Mesh(new THREE.DodecahedronGeometry(rk.r, 0), rockMat);
      mesh.position.set(rk.x, rk.r * 0.45, rk.z);
      mesh.rotation.y = rk.x;
      this.scene.add(mesh);
    }

    const trunkGeo = new THREE.CylinderGeometry(1, 1.2, 1, 6);
    trunkGeo.translate(0, 0.5, 0);
    const leafGeo = new THREE.ConeGeometry(1, 1, 6);
    leafGeo.translate(0, 0.45, 0);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x1a120c, roughness: 1 });
    const leafMat = new THREE.MeshStandardMaterial({ color: 0x0e1610, roughness: 1 });
    const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, this.level.trees.length);
    let leafCount = 0;
    for (const t of this.level.trees) if (t.leaf) leafCount++;
    const leaves = new THREE.InstancedMesh(leafGeo, leafMat, Math.max(1, leafCount));
    const dummy = new THREE.Object3D();
    let li = 0;
    for (let i = 0; i < this.level.trees.length; i++) {
      const t = this.level.trees[i];
      dummy.position.set(t.x, 0, t.z);
      dummy.scale.set(t.r, t.h, t.r);
      dummy.rotation.set(0, t.x * 0.2, 0);
      dummy.updateMatrix();
      trunks.setMatrixAt(i, dummy.matrix);
      if (t.leaf) {
        dummy.position.set(t.x, t.h * 0.62, t.z);
        dummy.scale.set(t.r * 3.4, t.h * 0.48, t.r * 3.4);
        dummy.rotation.set(0, t.z, 0);
        dummy.updateMatrix();
        leaves.setMatrixAt(li++, dummy.matrix);
      }
    }
    trunks.frustumCulled = false;
    leaves.frustumCulled = false;
    this.scene.add(trunks, leaves);

    this.buildBike();
    for (const it of this.level.items) {
      const { g, mats } = itemMesh(it);
      g.position.set(it.x, 0, it.z);
      this.scene.add(g);
      this.itemRoots.set(it.id, g);
      this.glows.push(...mats);
    }
  }

  private buildBike() {
    const g = new THREE.Group();
    const red = new THREE.MeshStandardMaterial({
      color: 0x6e2420,
      roughness: 0.55,
      metalness: 0.25,
      emissive: 0x2a0808,
      emissiveIntensity: 0.35,
    });
    const dark = new THREE.MeshStandardMaterial({ color: 0x161616, roughness: 0.45, metalness: 0.5 });
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.32, 1.25), red);
    body.position.y = 0.55;
    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.08, 0.42), dark);
    seat.position.set(0, 0.76, -0.08);
    const wheelGeo = new THREE.CylinderGeometry(0.28, 0.28, 0.1, 12);
    wheelGeo.rotateZ(Math.PI / 2);
    const w1 = new THREE.Mesh(wheelGeo, dark);
    w1.position.set(0, 0.28, 0.46);
    const w2 = new THREE.Mesh(wheelGeo, dark);
    w2.position.set(0, 0.28, -0.48);
    const bar = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.04, 0.04), dark);
    bar.position.set(0, 0.92, 0.42);
    const tail = new THREE.Mesh(
      new THREE.BoxGeometry(0.16, 0.07, 0.04),
      new THREE.MeshStandardMaterial({
        color: 0xff3318,
        emissive: 0xff2208,
        emissiveIntensity: 0.9,
      }),
    );
    tail.position.set(0, 0.62, -0.64);
    g.add(body, seat, w1, w2, bar, tail);
    g.position.set(this.level.bike.x, 0, this.level.bike.z);
    this.scene.add(g);
  }

  private paintGround() {
    const size = 768;
    const canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      const tex = new THREE.CanvasTexture(canvas);
      return tex;
    }
    const img = ctx.createImageData(size, size);
    const data = img.data;
    const span = 164;
    for (let y = 0; y < size; y++) {
      const wz = (y / size) * span - span / 2;
      for (let x = 0; x < size; x++) {
        const wx = (x / size) * span - span / 2;
        const n = Math.sin(wx * 0.7 + wz * 1.3) * 0.5 + 0.5;
        let r = 14 + n * 16;
        let g = 18 + n * 12;
        let b = 13 + n * 8;
        if (wz < -43 && wz > -55 && wx > -6 && wx < 32) {
          r *= 0.38;
          g *= 0.42;
          b *= 0.5;
        }
        const i = (y * size + x) * 4;
        data[i] = r;
        data[i + 1] = g;
        data[i + 2] = b;
        data[i + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 4;
    return tex;
  }
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      getPos: () => { x: number; y: number; z: number };
      setKeys: (codes: string[]) => void;
      setYaw: (y: number) => void;
      teleport: (x: number, z: number) => void;
      collectAll: () => void;
    };
  }
}

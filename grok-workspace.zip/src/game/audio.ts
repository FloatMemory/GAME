// Diegetic effects only. No music bed, no looped melody.

type Burst = {
  freq: number;
  q: number;
  dur: number;
  gain: number;
  pan: number;
  filter: BiquadFilterType;
  rate?: number;
};

export class Sfx {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private bus: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private volume = 0.8;
  private lastBreath = 0;
  private lastHeart = 0;

  unlock() {
    const Ctx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    if (!this.ctx) {
      this.ctx = new Ctx({ latencyHint: "interactive" });
      this.master = this.ctx.createGain();
      this.bus = this.ctx.createGain();
      this.bus.connect(this.master);
      this.master.connect(this.ctx.destination);
      this.applyVolume();
      this.makeNoise();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  resume() {
    if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
  }

  setVolume(v: number) {
    this.volume = Math.min(1, Math.max(0, v));
    this.applyVolume();
  }

  private applyVolume() {
    if (!this.master || !this.ctx) return;
    const g = this.volume * this.volume;
    this.master.gain.setTargetAtTime(g, this.ctx.currentTime, 0.02);
  }

  private makeNoise() {
    if (!this.ctx) return;
    const len = this.ctx.sampleRate;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    this.noise = buf;
  }

  private burst(o: Burst) {
    if (!this.ctx || !this.noise || !this.bus || this.volume <= 0.001) return;
    const ctx = this.ctx;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    src.playbackRate.value = o.rate ?? 1;
    const filter = ctx.createBiquadFilter();
    filter.type = o.filter;
    filter.frequency.value = o.freq;
    filter.Q.value = o.q;
    const gain = ctx.createGain();
    const panner = ctx.createStereoPanner();
    panner.pan.value = Math.max(-1, Math.min(1, o.pan));
    src.connect(filter);
    filter.connect(gain);
    gain.connect(panner);
    panner.connect(this.bus);
    const t = ctx.currentTime;
    const peak = Math.max(0.001, o.gain);
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(peak, t + 0.018);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + o.dur);
    src.start(t);
    src.stop(t + o.dur + 0.03);
    src.onended = () => {
      src.disconnect();
      filter.disconnect();
      gain.disconnect();
      panner.disconnect();
    };
  }

  step() {
    this.burst({
      freq: 180 + Math.random() * 80,
      q: 0.7,
      dur: 0.07,
      gain: 0.07 + Math.random() * 0.03,
      pan: (Math.random() - 0.5) * 0.3,
      filter: "bandpass",
      rate: 0.8 + Math.random() * 0.4,
    });
  }

  breath(pan: number, intensity: number) {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const gap = 0.7 - intensity * 0.28;
    if (now - this.lastBreath < gap) return;
    this.lastBreath = now;
    this.burst({
      freq: 120 + (1 - intensity) * 40,
      q: 0.6,
      dur: 0.32 + intensity * 0.18,
      gain: 0.03 + intensity * 0.2,
      pan,
      filter: "lowpass",
      rate: 0.55 + Math.random() * 0.2,
    });
  }

  heart(pan: number, intensity: number) {
    if (!this.ctx || !this.bus || this.volume <= 0.001) return;
    const now = this.ctx.currentTime;
    const gap = 0.72 - intensity * 0.38;
    if (now - this.lastHeart < gap) return;
    this.lastHeart = now;
    const osc = this.ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.setValueAtTime(62, now);
    osc.frequency.exponentialRampToValueAtTime(34, now + 0.12);
    const gain = this.ctx.createGain();
    const panner = this.ctx.createStereoPanner();
    panner.pan.value = Math.max(-1, Math.min(1, pan));
    osc.connect(gain);
    gain.connect(panner);
    panner.connect(this.bus);
    const peak = 0.08 + intensity * 0.16;
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(peak, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.15);
    osc.start(now);
    osc.stop(now + 0.17);
    osc.onended = () => {
      osc.disconnect();
      gain.disconnect();
      panner.disconnect();
    };
  }

  pickup() {
    this.burst({
      freq: 1400,
      q: 2,
      dur: 0.05,
      gain: 0.08,
      pan: 0,
      filter: "bandpass",
      rate: 1.2,
    });
    window.setTimeout(() => {
      this.burst({ freq: 900, q: 1.4, dur: 0.06, gain: 0.05, pan: 0, filter: "bandpass" });
    }, 70);
  }

  death() {
    this.burst({
      freq: 240,
      q: 0.4,
      dur: 0.55,
      gain: 0.35,
      pan: 0,
      filter: "lowpass",
      rate: 0.4,
    });
  }

  engine() {
    this.burst({
      freq: 90,
      q: 1.6,
      dur: 1.1,
      gain: 0.16,
      pan: 0,
      filter: "bandpass",
      rate: 0.35,
    });
  }
}

let singleton: Sfx | null = null;

export function primeAudio(): Sfx {
  if (!singleton) singleton = new Sfx();
  singleton.unlock();
  return singleton;
}

export function getSfx(): Sfx {
  if (!singleton) singleton = new Sfx();
  return singleton;
}

export function resumeAudio() {
  singleton?.resume();
}

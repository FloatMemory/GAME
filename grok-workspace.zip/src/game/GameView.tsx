import { useEffect, useRef, useState } from "react";
import { primeAudio } from "@/game/audio";
import type { ForestGame } from "@/game/engine";
import type { HudState, TouchInput } from "@/game/types";

const emptyHud = (): HudState => ({
  phase: "menu",
  battery: 1,
  stamina: 1,
  parts: [
    { id: "spark", name: "火花塞", where: "水泥房", got: false },
    { id: "oil", name: "机油", where: "木屋", got: false },
    { id: "pack", name: "电瓶", where: "断桥", got: false },
    { id: "tire", name: "轮胎", where: "迷宫", got: false },
  ],
  prompt: "",
  objective: "水泥房·火花塞   木屋·机油   断桥·电瓶   迷宫·轮胎",
  elapsed: 0,
  best: null,
  deaths: 0,
  threat: 0,
  sound: true,
  ready: false,
});

function fmt(sec: number) {
  const s = Math.max(0, Math.floor(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

export function GameView() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const touch = useRef<TouchInput>({
    moveX: 0,
    moveY: 0,
    lookX: 0,
    lookY: 0,
    sprint: false,
    interact: false,
  }).current;
  const engineRef = useRef<ForestGame | null>(null);
  const pending = useRef(false);
  const [hud, setHud] = useState<HudState>(emptyHud);
  const [touchUi, setTouchUi] = useState(false);
  const [locked, setLocked] = useState(false);

  useEffect(() => {
    const apply = () => {
      const coarse = window.matchMedia("(pointer: coarse)").matches || window.innerWidth < 860;
      setTouchUi(coarse);
      engineRef.current && (engineRef.current.touchUi = coarse);
    };
    apply();
    window.addEventListener("resize", apply);
    const onLock = () => setLocked(document.pointerLockElement != null);
    document.addEventListener("pointerlockchange", onLock);
    let dead = false;
    let game: ForestGame | null = null;
    void import("@/game/engine").then(({ ForestGame }) => {
      if (dead || !canvasRef.current) return;
      game = new ForestGame(canvasRef.current, touch, setHud);
      game.touchUi = window.matchMedia("(pointer: coarse)").matches || window.innerWidth < 860;
      engineRef.current = game;
      game.start();
      if (pending.current) {
        pending.current = false;
        game.begin();
      }
    });
    return () => {
      dead = true;
      window.removeEventListener("resize", apply);
      document.removeEventListener("pointerlockchange", onLock);
      game?.dispose();
      engineRef.current = null;
    };
  }, [touch]);

  function onStart() {
    primeAudio();
    if (!engineRef.current) {
      pending.current = true;
      return;
    }
    engineRef.current.begin();
  }

  function onResume() {
    primeAudio();
    engineRef.current?.resume();
  }

  function toggleSound() {
    primeAudio();
    engineRef.current?.setSound(!hud.sound);
  }

  const playing = hud.phase === "play" || hud.phase === "scare";
  const got = hud.parts.filter((p) => p.got).length;

  return (
    <main className="relative h-dvh w-full select-none overflow-hidden bg-bg text-fg">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" />
      {playing && <div className="grain" aria-hidden="true" />}
      {playing && (
        <div className="threat" style={{ opacity: Math.min(0.85, hud.threat) }} aria-hidden="true" />
      )}

      {playing && (
        <>
          <div className="pointer-events-none absolute top-4 right-4 left-4 flex items-start justify-between gap-4">
            <div className="w-36">
              <div className="mb-1 flex items-center justify-between text-xs text-muted">
                <span>手电</span>
                <span>{Math.round(hud.battery * 100)}</span>
              </div>
              <div className="h-1.5 bg-line">
                <div
                  className={hud.battery < 0.2 ? "h-full bg-bloodhot" : "h-full bg-paper"}
                  style={{ width: `${Math.round(hud.battery * 100)}%` }}
                />
              </div>
              {hud.battery < 0.2 && <p className="mt-1 text-xs text-bloodhot">快没电了</p>}
              {hud.stamina < 0.98 && (
                <div className="mt-3 h-1 bg-line">
                  <div className="h-full bg-moon" style={{ width: `${Math.round(hud.stamina * 100)}%` }} />
                </div>
              )}
            </div>
            <div className="text-right">
              <p className="font-display text-lg text-paper">
                {got}/4
              </p>
              <p className="text-xs text-muted">{fmt(hud.elapsed)}</p>
            </div>
          </div>
          <div className="pointer-events-none absolute top-1/2 left-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-paper" />
          <div className="pointer-events-none absolute right-4 bottom-28 left-4 text-center sm:bottom-10">
            {hud.prompt && <p className="font-display text-lg text-paper">{hud.prompt}</p>}
            <p className="mt-1 text-xs text-muted">{hud.objective}</p>
          </div>
          {!touchUi && !locked && hud.phase === "play" && (
            <p className="pointer-events-none absolute bottom-6 left-1/2 -translate-x-1/2 text-xs text-muted">
              点击画面转动视角
            </p>
          )}
        </>
      )}

      {touchUi && hud.phase === "play" && <TouchControls touch={touch} />}

      {hud.phase === "menu" && (
        <section className="absolute inset-0 flex flex-col justify-end bg-bg px-6 pt-16 pb-8 sm:px-12 sm:pb-12">
          <div className="max-w-lg">
            <p className="text-xs tracking-widest text-blood">夜 · 林间近道</p>
            <h1 className="mt-2 font-display text-6xl text-blood sm:text-8xl">近路</h1>
            <p className="mt-4 max-w-md text-base leading-relaxed text-fg">
              摩托车在林子里熄了火。火花塞、机油、电瓶、轮胎，找齐才能发动。从你走进来的那一刻，就有东西在跟着。
            </p>
            <p className="mt-3 text-sm leading-relaxed text-muted">
              水泥房在路东，木屋在路西，电瓶在南边断桥，轮胎在铁丝迷宫尽头。它比走路快，只有跑起来才拉得开。手电会没电，地上有电池。碰到它，就结束。
            </p>
            <button
              type="button"
              id="start-btn"
              onClick={onStart}
              className="mt-6 bg-blood px-8 py-3 font-display text-lg text-paper"
            >
              进入森林
            </button>
            <p className="mt-4 text-xs leading-relaxed text-muted">
              WASD 移动 · 鼠标环视 · Shift 奔跑 · E 拾取 · ESC 暂停
            </p>
            <p className="mt-1 text-xs text-muted">没有背景音乐。只有脚步，和它的呼吸。</p>
            <button type="button" onClick={toggleSound} className="mt-4 text-sm text-moon">
              音效 {hud.sound ? "开" : "关"}
            </button>
          </div>
        </section>
      )}

      {hud.phase === "pause" && (
        <section className="absolute inset-0 flex flex-col justify-end bg-bg/90 px-6 pt-16 pb-8 sm:px-12">
          <div className="max-w-lg">
            <h2 className="font-display text-4xl text-paper">停住</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted">
              它没有停。零件还在原来的地方：水泥房、木屋、断桥、迷宫。回到北边的摩托车。
            </p>
            <p className="mt-2 text-sm text-fg">{hud.objective}</p>
            <button
              type="button"
              onClick={onResume}
              className="mt-6 bg-blood px-8 py-3 font-display text-lg text-paper"
            >
              继续走
            </button>
            <button type="button" onClick={toggleSound} className="mt-4 block text-sm text-moon">
              音效 {hud.sound ? "开" : "关"}
            </button>
          </div>
        </section>
      )}

      {hud.phase === "dead" && (
        <section className="absolute inset-0 flex flex-col justify-between bg-bg px-6 py-10 sm:px-12">
          <p className="text-sm tracking-widest text-blood">寻人启事</p>
          <div className="max-w-lg">
            <h2 className="font-display text-4xl text-paper sm:text-5xl">你没有回来</h2>
            <p className="mt-4 leading-relaxed text-muted">
              最后出现在林间近道。走了 {fmt(hud.elapsed)}。这是第 {hud.deaths} 次。
            </p>
            <p className="mt-2 text-sm text-muted">零件会回到原处。它也会。</p>
          </div>
          <button
            type="button"
            onClick={onStart}
            className="w-fit bg-blood px-8 py-3 font-display text-lg text-paper"
          >
            再走一次
          </button>
        </section>
      )}

      {hud.phase === "win" && (
        <section className="absolute inset-0 flex flex-col justify-between bg-bg px-6 py-10 sm:px-12">
          <p className="text-sm tracking-widest text-moon">引擎响了</p>
          <div className="max-w-lg">
            <h2 className="font-display text-4xl text-paper sm:text-5xl">你没有回头</h2>
            <p className="mt-4 leading-relaxed text-fg">用时 {fmt(hud.elapsed)}</p>
            {hud.best != null && <p className="mt-1 text-sm text-muted">最短 {fmt(hud.best)}</p>}
          </div>
          <button
            type="button"
            onClick={onStart}
            className="w-fit bg-blood px-8 py-3 font-display text-lg text-paper"
          >
            再走一次
          </button>
        </section>
      )}
    </main>
  );
}

function TouchControls({ touch }: { touch: TouchInput }) {
  return (
    <div className="absolute inset-0 touch-none">
      <LookPad touch={touch} />
      <Stick touch={touch} />
      <div className="absolute right-4 bottom-6 z-10 flex gap-3">
        <HoldButton label="奔跑" onChange={(v) => (touch.sprint = v)} />
        <HoldButton label="拾取" onChange={(v) => (touch.interact = v)} />
      </div>
    </div>
  );
}

function HoldButton({ label, onChange }: { label: string; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      className="h-14 min-w-14 border border-line bg-surface px-4 text-sm text-paper"
      onPointerDown={(e) => {
        e.stopPropagation();
        e.currentTarget.setPointerCapture(e.pointerId);
        onChange(true);
      }}
      onPointerUp={(e) => {
        e.stopPropagation();
        onChange(false);
      }}
      onPointerCancel={() => onChange(false)}
    >
      {label}
    </button>
  );
}

function Stick({ touch }: { touch: TouchInput }) {
  const base = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  function setFrom(clientX: number, clientY: number) {
    const rect = base.current?.getBoundingClientRect();
    if (!rect) return;
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const max = rect.width * 0.36;
    const len = Math.hypot(dx, dy) || 1;
    const cl = Math.min(len, max);
    dx = (dx / len) * cl;
    dy = (dy / len) * cl;
    touch.moveX = dx / max;
    touch.moveY = -dy / max;
    setKnob({ x: dx, y: dy });
  }
  function end() {
    touch.moveX = 0;
    touch.moveY = 0;
    setKnob({ x: 0, y: 0 });
  }
  return (
    <div
      ref={base}
      className="absolute bottom-6 left-4 z-10 h-32 w-32 rounded-full border border-line bg-surface/80"
      onPointerDown={(e) => {
        e.stopPropagation();
        e.currentTarget.setPointerCapture(e.pointerId);
        setFrom(e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        if (e.currentTarget.hasPointerCapture(e.pointerId)) setFrom(e.clientX, e.clientY);
      }}
      onPointerUp={end}
      onPointerCancel={end}
    >
      <div
        className="absolute top-1/2 left-1/2 h-12 w-12 rounded-full bg-paper"
        style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
      />
    </div>
  );
}

function LookPad({ touch }: { touch: TouchInput }) {
  const last = useRef<{ x: number; y: number } | null>(null);
  return (
    <div
      className="absolute inset-y-0 right-0 w-1/2"
      onPointerDown={(e) => {
        if ((e.target as HTMLElement).closest("button")) return;
        e.currentTarget.setPointerCapture(e.pointerId);
        last.current = { x: e.clientX, y: e.clientY };
      }}
      onPointerMove={(e) => {
        if (!last.current) return;
        touch.lookX += e.clientX - last.current.x;
        touch.lookY += e.clientY - last.current.y;
        last.current = { x: e.clientX, y: e.clientY };
      }}
      onPointerUp={() => {
        last.current = null;
      }}
      onPointerCancel={() => {
        last.current = null;
      }}
    />
  );
}

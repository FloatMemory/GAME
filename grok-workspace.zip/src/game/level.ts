export type Wall = {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  h: number;
  color: number;
};

export type Tree = {
  x: number;
  z: number;
  r: number;
  h: number;
  leaf: boolean;
};

export type ItemKind = "spark" | "oil" | "pack" | "tire" | "cell";

export type ItemDef = {
  id: string;
  kind: ItemKind;
  name: string;
  where: string;
  x: number;
  z: number;
  part: boolean;
};

export type Level = {
  trees: Tree[];
  walls: Wall[];
  rocks: { x: number; z: number; r: number }[];
  items: ItemDef[];
  bike: { x: number; z: number };
  spawn: { x: number; z: number };
  monster: { x: number; z: number };
  road: [number, number][];
};

const CONCRETE = 0x6a675f;
const WOOD = 0x4a3422;
const FENCE = 0x2c332c;

function hash(x: number, z: number): number {
  const n = Math.sin(x * 127.1 + z * 311.7) * 43758.5453;
  return n - Math.floor(n);
}

function house(
  cx: number,
  cz: number,
  hx: number,
  hz: number,
  doors: Array<"n" | "s" | "w" | "e">,
  h: number,
  color: number,
): Wall[] {
  const t = 0.4;
  const gap = 1.7;
  const minX = cx - hx;
  const maxX = cx + hx;
  const minZ = cz - hz;
  const maxZ = cz + hz;
  const walls: Wall[] = [];
  const add = (a: number, b: number, c: number, d: number) => {
    if (b - a < 0.05 || d - c < 0.05) return;
    walls.push({ minX: a, maxX: b, minZ: c, maxZ: d, h, color });
  };
  const open = (side: "n" | "s" | "w" | "e") => doors.includes(side);

  if (open("n")) {
    add(minX, cx - gap / 2, minZ, minZ + t);
    add(cx + gap / 2, maxX, minZ, minZ + t);
  } else add(minX, maxX, minZ, minZ + t);

  if (open("s")) {
    add(minX, cx - gap / 2, maxZ - t, maxZ);
    add(cx + gap / 2, maxX, maxZ - t, maxZ);
  } else add(minX, maxX, maxZ - t, maxZ);

  if (open("w")) {
    add(minX, minX + t, minZ, cz - gap / 2);
    add(minX, minX + t, cz + gap / 2, maxZ);
  } else add(minX, minX + t, minZ, maxZ);

  if (open("e")) {
    add(maxX - t, maxX, minZ, cz - gap / 2);
    add(maxX - t, maxX, cz + gap / 2, maxZ);
  } else add(maxX - t, maxX, minZ, maxZ);

  return walls;
}

function fence(minX: number, maxX: number, minZ: number, maxZ: number): Wall {
  return { minX, maxX, minZ, maxZ, h: 1.28, color: FENCE };
}

export function createLevel(): Level {
  const road: [number, number][] = [
    [0, 42],
    [0, 24],
    [0, 8],
    [-5, -8],
    [-3, -26],
    [10, -42],
    [4, -56],
    [-12, -74],
  ];

  const walls: Wall[] = [
    ...house(11, 2, 3.1, 2.45, ["w", "e"], 2.7, CONCRETE),
    ...house(-14, -12, 2.7, 2.35, ["w", "e"], 2.45, WOOD),
    fence(-30, -17, -58.5, -57.9),
    fence(-13, -2, -58.5, -57.9),
    fence(-30, -29.4, -78, -62),
    fence(-30, -29.4, -60.5, -58),
    fence(-2.6, -2, -78, -58),
    fence(-24, -23.35, -74, -62),
    fence(-23, -11, -68.5, -67.9),
    fence(-16, -15.35, -74, -68),
    fence(-12, -11.35, -66, -60),
    fence(-22, -8, -74.5, -73.9),
    fence(-30, -11, -78, -77.4),
    fence(-5.2, -2, -78, -77.4),
  ];

  const items: ItemDef[] = [
    { id: "spark", kind: "spark", name: "火花塞", where: "水泥房", x: 11, z: 2, part: true },
    { id: "oil", kind: "oil", name: "机油", where: "木屋", x: -14, z: -12, part: true },
    { id: "pack", kind: "pack", name: "电瓶", where: "断桥", x: 12, z: -49, part: true },
    { id: "tire", kind: "tire", name: "轮胎", where: "迷宫", x: -8, z: -75, part: true },
    { id: "c1", kind: "cell", name: "电池", where: "", x: 5, z: 10, part: false },
    { id: "c2", kind: "cell", name: "电池", where: "", x: -8, z: -2, part: false },
    { id: "c3", kind: "cell", name: "电池", where: "", x: 16, z: -18, part: false },
    { id: "c4", kind: "cell", name: "电池", where: "", x: -6, z: -34, part: false },
    { id: "c5", kind: "cell", name: "电池", where: "", x: 6, z: -60, part: false },
    { id: "c6", kind: "cell", name: "电池", where: "", x: -22, z: -64, part: false },
  ];

  const rocks = [
    { x: 4.2, z: 0.5, r: 0.7 },
    { x: -9, z: -22, r: 0.85 },
    { x: 6, z: -34, r: 0.65 },
    { x: 18, z: -40, r: 0.9 },
  ];

  const bike = { x: 2.5, z: 30 };
  const spawn = { x: 0, z: 18 };
  const monster = { x: 36, z: -16 };

  const trees: Tree[] = [];
  const blocked = (x: number, z: number) => {
    if (distToRoad(x, z, road) < 4.3) return true;
    if (Math.hypot(x - spawn.x, z - spawn.z) < 6) return true;
    if (Math.hypot(x - bike.x, z - bike.z) < 5) return true;
    if (Math.hypot(x - monster.x, z - monster.z) < 4) return true;
    if (Math.abs(x - 11) < 6.2 && Math.abs(z - 2) < 5.2) return true;
    if (Math.abs(x + 14) < 5.6 && Math.abs(z + 12) < 5) return true;
    if (x > -32 && x < 0 && z > -80 && z < -56) return true;
    if (Math.hypot(x - 12, z + 49) < 7) return true;
    for (const it of items) if (Math.hypot(x - it.x, z - it.z) < 1.4) return true;
    for (const rk of rocks) if (Math.hypot(x - rk.x, z - rk.z) < rk.r + 1.1) return true;
    return false;
  };

  for (let gx = -74; gx <= 74; gx += 5.7) {
    for (let gz = -74; gz <= 74; gz += 5.7) {
      const jx = gx + (hash(gx, gz) - 0.5) * 3.4;
      const jz = gz + (hash(gz, gx + 4) - 0.5) * 3.4;
      if (Math.hypot(jx, jz) > 76) continue;
      if (blocked(jx, jz)) continue;
      const n = hash(jx + 3, jz - 2);
      const bamboo = n < 0.18;
      const dead = !bamboo && n > 0.82;
      trees.push({
        x: jx,
        z: jz,
        r: bamboo ? 0.11 + hash(jx, jz + 1) * 0.05 : 0.22 + n * 0.28,
        h: bamboo ? 8 + hash(jx + 1, jz) * 4 : dead ? 6 + n * 3 : 5.5 + n * 8,
        leaf: !bamboo && !dead,
      });
    }
  }

  return { trees, walls, rocks, items, bike, spawn, monster, road };
}

export function distToRoad(x: number, z: number, road: [number, number][]): number {
  let best = 1e9;
  for (let i = 0; i < road.length - 1; i++) {
    const ax = road[i][0];
    const az = road[i][1];
    const bx = road[i + 1][0];
    const bz = road[i + 1][1];
    const abx = bx - ax;
    const abz = bz - az;
    const den = abx * abx + abz * abz || 1;
    const t = Math.max(0, Math.min(1, ((x - ax) * abx + (z - az) * abz) / den));
    const cx = ax + abx * t;
    const cz = az + abz * t;
    const d = Math.hypot(x - cx, z - cz);
    if (d < best) best = d;
  }
  return best;
}

import { n as getSfx } from "./routes-BGwLNA7_.mjs";
import { C as SphereGeometry, D as Vector3, E as TorusGeometry, S as Scene, T as Timer, _ as MeshStandardMaterial, a as CapsuleGeometry, b as PlaneGeometry, c as CylinderGeometry, d as FogExp2, f as Group, g as MeshBasicMaterial, h as Mesh, i as CanvasTexture, l as DirectionalLight, m as InstancedMesh, n as AmbientLight, o as CircleGeometry, p as HemisphereLight, r as BoxGeometry, s as ConeGeometry, t as WebGLRenderer, u as DodecahedronGeometry, v as Object3D, w as SpotLight, x as SRGBColorSpace, y as PerspectiveCamera } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-BupMWj5D.js
var CONCRETE = 6973279;
var WOOD = 4863010;
var FENCE = 2896684;
function hash(x, z) {
	const n = Math.sin(x * 127.1 + z * 311.7) * 43758.5453;
	return n - Math.floor(n);
}
function house(cx, cz, hx, hz, doors, h, color) {
	const t = .4;
	const gap = 1.7;
	const minX = cx - hx;
	const maxX = cx + hx;
	const minZ = cz - hz;
	const maxZ = cz + hz;
	const walls = [];
	const add = (a, b, c, d) => {
		if (b - a < .05 || d - c < .05) return;
		walls.push({
			minX: a,
			maxX: b,
			minZ: c,
			maxZ: d,
			h,
			color
		});
	};
	const open = (side) => doors.includes(side);
	if (open("n")) {
		add(minX, cx - gap / 2, minZ, minZ + t);
		add(cx + gap / 2, maxX, minZ, minZ + t);
	} else add(minX, maxX, minZ, minZ + t);
	if (open("s")) {
		add(minX, cx - gap / 2, maxZ - t, maxZ);
		add(cx + gap / 2, maxX, maxZ - t, maxZ);
	} else add(minX, maxX, maxZ - t, maxZ);
	if (open("w")) {
		add(minX, minX + t, minZ, cz - gap / 2);
		add(minX, minX + t, cz + gap / 2, maxZ);
	} else add(minX, minX + t, minZ, maxZ);
	if (open("e")) {
		add(maxX - t, maxX, minZ, cz - gap / 2);
		add(maxX - t, maxX, cz + gap / 2, maxZ);
	} else add(maxX - t, maxX, minZ, maxZ);
	return walls;
}
function fence(minX, maxX, minZ, maxZ) {
	return {
		minX,
		maxX,
		minZ,
		maxZ,
		h: 1.28,
		color: FENCE
	};
}
function createLevel() {
	const road = [
		[0, 42],
		[0, 24],
		[0, 8],
		[-5, -8],
		[-3, -26],
		[10, -42],
		[4, -56],
		[-12, -74]
	];
	const walls = [
		...house(11, 2, 3.1, 2.45, ["w", "e"], 2.7, CONCRETE),
		...house(-14, -12, 2.7, 2.35, ["w", "e"], 2.45, WOOD),
		fence(-30, -17, -58.5, -57.9),
		fence(-13, -2, -58.5, -57.9),
		fence(-30, -29.4, -78, -62),
		fence(-30, -29.4, -60.5, -58),
		fence(-2.6, -2, -78, -58),
		fence(-24, -23.35, -74, -62),
		fence(-23, -11, -68.5, -67.9),
		fence(-16, -15.35, -74, -68),
		fence(-12, -11.35, -66, -60),
		fence(-22, -8, -74.5, -73.9),
		fence(-30, -11, -78, -77.4),
		fence(-5.2, -2, -78, -77.4)
	];
	const items = [
		{
			id: "spark",
			kind: "spark",
			name: "火花塞",
			where: "水泥房",
			x: 11,
			z: 2,
			part: true
		},
		{
			id: "oil",
			kind: "oil",
			name: "机油",
			where: "木屋",
			x: -14,
			z: -12,
			part: true
		},
		{
			id: "pack",
			kind: "pack",
			name: "电瓶",
			where: "断桥",
			x: 12,
			z: -49,
			part: true
		},
		{
			id: "tire",
			kind: "tire",
			name: "轮胎",
			where: "迷宫",
			x: -8,
			z: -75,
			part: true
		},
		{
			id: "c1",
			kind: "cell",
			name: "电池",
			where: "",
			x: 5,
			z: 10,
			part: false
		},
		{
			id: "c2",
			kind: "cell",
			name: "电池",
			where: "",
			x: -8,
			z: -2,
			part: false
		},
		{
			id: "c3",
			kind: "cell",
			name: "电池",
			where: "",
			x: 16,
			z: -18,
			part: false
		},
		{
			id: "c4",
			kind: "cell",
			name: "电池",
			where: "",
			x: -6,
			z: -34,
			part: false
		},
		{
			id: "c5",
			kind: "cell",
			name: "电池",
			where: "",
			x: 6,
			z: -60,
			part: false
		},
		{
			id: "c6",
			kind: "cell",
			name: "电池",
			where: "",
			x: -22,
			z: -64,
			part: false
		}
	];
	const rocks = [
		{
			x: 4.2,
			z: .5,
			r: .7
		},
		{
			x: -9,
			z: -22,
			r: .85
		},
		{
			x: 6,
			z: -34,
			r: .65
		},
		{
			x: 18,
			z: -40,
			r: .9
		}
	];
	const bike = {
		x: 2.5,
		z: 30
	};
	const spawn = {
		x: 0,
		z: 18
	};
	const monster = {
		x: 36,
		z: -16
	};
	const trees = [];
	const blocked = (x, z) => {
		if (distToRoad(x, z, road) < 4.3) return true;
		if (Math.hypot(x - spawn.x, z - spawn.z) < 6) return true;
		if (Math.hypot(x - bike.x, z - bike.z) < 5) return true;
		if (Math.hypot(x - monster.x, z - monster.z) < 4) return true;
		if (Math.abs(x - 11) < 6.2 && Math.abs(z - 2) < 5.2) return true;
		if (Math.abs(x + 14) < 5.6 && Math.abs(z + 12) < 5) return true;
		if (x > -32 && x < 0 && z > -80 && z < -56) return true;
		if (Math.hypot(x - 12, z + 49) < 7) return true;
		for (const it of items) if (Math.hypot(x - it.x, z - it.z) < 1.4) return true;
		for (const rk of rocks) if (Math.hypot(x - rk.x, z - rk.z) < rk.r + 1.1) return true;
		return false;
	};
	for (let gx = -74; gx <= 74; gx += 5.7) for (let gz = -74; gz <= 74; gz += 5.7) {
		const jx = gx + (hash(gx, gz) - .5) * 3.4;
		const jz = gz + (hash(gz, gx + 4) - .5) * 3.4;
		if (Math.hypot(jx, jz) > 76) continue;
		if (blocked(jx, jz)) continue;
		const n = hash(jx + 3, jz - 2);
		const bamboo = n < .18;
		const dead = !bamboo && n > .82;
		trees.push({
			x: jx,
			z: jz,
			r: bamboo ? .11 + hash(jx, jz + 1) * .05 : .22 + n * .28,
			h: bamboo ? 8 + hash(jx + 1, jz) * 4 : dead ? 6 + n * 3 : 5.5 + n * 8,
			leaf: !bamboo && !dead
		});
	}
	return {
		trees,
		walls,
		rocks,
		items,
		bike,
		spawn,
		monster,
		road
	};
}
function distToRoad(x, z, road) {
	let best = 1e9;
	for (let i = 0; i < road.length - 1; i++) {
		const ax = road[i][0];
		const az = road[i][1];
		const bx = road[i + 1][0];
		const bz = road[i + 1][1];
		const abx = bx - ax;
		const abz = bz - az;
		const den = abx * abx + abz * abz || 1;
		const t = Math.max(0, Math.min(1, ((x - ax) * abx + (z - az) * abz) / den));
		const cx = ax + abx * t;
		const cz = az + abz * t;
		const d = Math.hypot(x - cx, z - cz);
		if (d < best) best = d;
	}
	return best;
}
var SAVE_KEY = "jinlu-save-v1";
var EYE = 1.64;
var PLAYER_R = .36;
var MONSTER_R = .46;
var WALK = 3.45;
var SPRINT = 6.55;
var CATCH = 1.12;
var WORLD_UP = new Vector3(0, 1, 0);
function clamp(v, a, b) {
	return Math.max(a, Math.min(b, v));
}
function resolve(x, z, radius, level) {
	let px = x;
	let pz = z;
	const circles = level.trees;
	for (let pass = 0; pass < 2; pass++) {
		for (let i = 0; i < circles.length; i++) {
			const t = circles[i];
			const dx = px - t.x;
			const dz = pz - t.z;
			const min = radius + t.r;
			const d2 = dx * dx + dz * dz;
			if (d2 >= min * min) continue;
			if (d2 > 1e-8) {
				const d = Math.sqrt(d2);
				const s = (min - d) / d;
				px += dx * s;
				pz += dz * s;
			} else px += min;
		}
		for (let i = 0; i < level.rocks.length; i++) {
			const t = level.rocks[i];
			const dx = px - t.x;
			const dz = pz - t.z;
			const min = radius + t.r;
			const d2 = dx * dx + dz * dz;
			if (d2 >= min * min) continue;
			if (d2 > 1e-8) {
				const d = Math.sqrt(d2);
				const s = (min - d) / d;
				px += dx * s;
				pz += dz * s;
			} else px += min;
		}
		{
			const dx = px - level.bike.x;
			const dz = pz - level.bike.z;
			const min = radius + .8;
			const d2 = dx * dx + dz * dz;
			if (d2 < min * min) {
				if (d2 > 1e-8) {
					const d = Math.sqrt(d2);
					const s = (min - d) / d;
					px += dx * s;
					pz += dz * s;
				} else px += min;
			}
		}
		const walls = level.walls;
		for (let i = 0; i < walls.length; i++) {
			const w = walls[i];
			const cx = clamp(px, w.minX, w.maxX);
			const cz = clamp(pz, w.minZ, w.maxZ);
			const dx = px - cx;
			const dz = pz - cz;
			const d2 = dx * dx + dz * dz;
			if (d2 >= radius * radius) continue;
			if (d2 > 1e-6) {
				const d = Math.sqrt(d2);
				const s = (radius - d) / d;
				px += dx * s;
				pz += dz * s;
			} else {
				const left = px - w.minX;
				const right = w.maxX - px;
				const down = pz - w.minZ;
				const up = w.maxZ - pz;
				const m = Math.min(left, right, down, up);
				if (m === left) px = w.minX - radius;
				else if (m === right) px = w.maxX + radius;
				else if (m === down) pz = w.minZ - radius;
				else pz = w.maxZ + radius;
			}
		}
		px = clamp(px, -76, 76);
		pz = clamp(pz, -76, 76);
	}
	return {
		x: px,
		z: pz
	};
}
function losBlocked(x0, z0, x1, z1, walls) {
	const dx = x1 - x0;
	const dz = z1 - z0;
	for (let i = 0; i < walls.length; i++) {
		const w = walls[i];
		let t0 = 0;
		let t1 = 1;
		const planes = [
			[-dx, x0 - w.minX],
			[dx, w.maxX - x0],
			[-dz, z0 - w.minZ],
			[dz, w.maxZ - z0]
		];
		let hit = true;
		for (let p = 0; p < 4; p++) {
			const denom = planes[p][0];
			const numer = planes[p][1];
			if (Math.abs(denom) < 1e-8) {
				if (numer < 0) {
					hit = false;
					break;
				}
			} else {
				const t = numer / denom;
				if (denom < 0) {
					if (t > t1) {
						hit = false;
						break;
					}
					if (t > t0) t0 = t;
				} else {
					if (t < t0) {
						hit = false;
						break;
					}
					if (t < t1) t1 = t;
				}
			}
		}
		if (hit && t1 >= t0) return true;
	}
	return false;
}
function buildMonster() {
	const group = new Group();
	const skin = new MeshStandardMaterial({
		color: 13157048,
		roughness: .72,
		metalness: .02,
		emissive: 2757650,
		emissiveIntensity: .45
	});
	const dark = new MeshStandardMaterial({
		color: 1182732,
		roughness: 1
	});
	const torso = new Mesh(new CapsuleGeometry(.26, .72, 4, 8), skin);
	torso.position.y = 1.28;
	const neck = new Mesh(new CylinderGeometry(.08, .1, .28, 8), skin);
	neck.position.y = 1.82;
	const headPivot = new Group();
	headPivot.position.y = 2.05;
	const head = new Mesh(new SphereGeometry(.2, 12, 10), skin);
	head.scale.set(.78, 1.22, .86);
	const pitGeo = new SphereGeometry(.035, 8, 6);
	const pitL = new Mesh(pitGeo, dark);
	pitL.position.set(-.07, .02, .14);
	const pitR = new Mesh(pitGeo, dark);
	pitR.position.set(.07, .02, .14);
	const mouth = new Mesh(new BoxGeometry(.05, .16, .04), dark);
	mouth.position.set(0, -.08, .15);
	headPivot.add(head, pitL, pitR, mouth);
	const armL = new Group();
	armL.position.set(-.32, 1.62, 0);
	const armR = new Group();
	armR.position.set(.32, 1.62, 0);
	const armGeo = new CapsuleGeometry(.055, .95, 3, 6);
	const aL = new Mesh(armGeo, skin);
	aL.position.y = -.55;
	const aR = new Mesh(armGeo, skin);
	aR.position.y = -.55;
	armL.add(aL);
	armR.add(aR);
	const legL = new Group();
	legL.position.set(-.12, .86, 0);
	const legR = new Group();
	legR.position.set(.12, .86, 0);
	const legGeo = new CapsuleGeometry(.07, .7, 3, 6);
	const lL = new Mesh(legGeo, skin);
	lL.position.y = -.42;
	const lR = new Mesh(legGeo, skin);
	lR.position.y = -.42;
	legL.add(lL);
	legR.add(lR);
	group.add(torso, neck, headPivot, armL, armR, legL, legR);
	return {
		group,
		armL,
		armR,
		legL,
		legR,
		mouth,
		head: headPivot
	};
}
function buildTorch() {
	const g = new Group();
	const bodyMat = new MeshStandardMaterial({
		color: 2763816,
		roughness: .4,
		metalness: .6
	});
	const geo = new CylinderGeometry(.042, .05, .28, 8);
	geo.rotateX(-Math.PI / 2);
	const body = new Mesh(geo, bodyMat);
	const headGeo = new CylinderGeometry(.07, .048, .09, 8);
	headGeo.rotateX(-Math.PI / 2);
	const head = new Mesh(headGeo, bodyMat);
	head.position.z = -.17;
	const lens = new Mesh(new CircleGeometry(.055, 12), new MeshBasicMaterial({ color: 16773576 }));
	lens.position.z = -.216;
	const arm = new Mesh(new BoxGeometry(.09, .09, .34), new MeshStandardMaterial({
		color: 3811874,
		roughness: .85
	}));
	arm.position.set(.04, -.08, .16);
	g.add(body, head, lens, arm);
	return g;
}
function itemMesh(def) {
	const g = new Group();
	const glow = (color, em, emI) => new MeshStandardMaterial({
		color,
		roughness: .45,
		metalness: .35,
		emissive: em,
		emissiveIntensity: emI
	});
	if (def.kind === "spark") {
		const m = glow(13685976, 6706483, .55);
		const mesh = new Mesh(new CylinderGeometry(.045, .045, .22, 8), m);
		mesh.position.y = .28;
		g.add(mesh);
		return {
			g,
			mats: [m]
		};
	}
	if (def.kind === "oil") {
		const m = glow(13017658, 6705168, .45);
		const mesh = new Mesh(new BoxGeometry(.2, .28, .14), m);
		mesh.position.y = .22;
		g.add(mesh);
		return {
			g,
			mats: [m]
		};
	}
	if (def.kind === "pack") {
		const m = glow(2369064, 4460560, .4);
		const mesh = new Mesh(new BoxGeometry(.32, .2, .18), m);
		mesh.position.y = .18;
		const cap = new Mesh(new BoxGeometry(.08, .06, .06), new MeshStandardMaterial({
			color: 9379101,
			roughness: .5,
			emissive: 9379101,
			emissiveIntensity: .4
		}));
		cap.position.set(0, .3, 0);
		g.add(mesh, cap);
		return {
			g,
			mats: [m]
		};
	}
	if (def.kind === "tire") {
		const m = glow(1710618, 2236962, .25);
		const mesh = new Mesh(new TorusGeometry(.28, .08, 8, 14), m);
		mesh.position.y = .32;
		g.add(mesh);
		return {
			g,
			mats: [m]
		};
	}
	const m = glow(13942906, 8939042, .9);
	const mesh = new Mesh(new CylinderGeometry(.055, .055, .16, 8), m);
	mesh.position.y = .16;
	g.add(mesh);
	return {
		g,
		mats: [m]
	};
}
var ForestGame = class {
	canvas;
	touch;
	onHud;
	renderer;
	scene = new Scene();
	camera;
	yaw = new Group();
	pitch = new Group();
	spot;
	torch;
	timer = new Timer();
	level;
	monster;
	sfx;
	keys = /* @__PURE__ */ new Set();
	injected = null;
	lookX = 0;
	lookY = 0;
	x = 0;
	z = 0;
	vx = 0;
	vz = 0;
	mx = 0;
	mz = 0;
	actualSpeed = 0;
	phase = "menu";
	battery = 1;
	stamina = 1;
	sprintLock = false;
	sprinting = false;
	elapsed = 0;
	darkT = 0;
	bob = 0;
	stepAcc = 0;
	threat = 0;
	scareLeft = 0;
	walkT = 0;
	best = null;
	deaths = 0;
	sound = true;
	prompt = "";
	objective = "";
	collected = /* @__PURE__ */ new Set();
	itemRoots = /* @__PURE__ */ new Map();
	glows = [];
	wasLocked = false;
	prevInteract = false;
	interactQueued = false;
	disposed = false;
	clockT = 0;
	touchUi = false;
	_fwd = new Vector3();
	_right = new Vector3();
	_cam = new Vector3();
	lastEmit = "";
	onResize;
	onKeyDown;
	onKeyUp;
	onBlur;
	onLock;
	onPointerDown;
	onPointerMove;
	onVis;
	constructor(canvas, touch, onHud) {
		this.canvas = canvas;
		this.touch = touch;
		this.onHud = onHud;
		this.level = createLevel();
		this.sfx = getSfx();
		this.renderer = new WebGLRenderer({
			canvas,
			antialias: true,
			powerPreference: "high-performance",
			alpha: false
		});
		this.renderer.outputColorSpace = SRGBColorSpace;
		this.renderer.toneMapping = 4;
		this.renderer.toneMappingExposure = .78;
		this.renderer.setClearColor(461067, 1);
		const dpr = Math.min(window.devicePixelRatio || 1, window.innerWidth < 800 ? 1.25 : 1.6);
		this.renderer.setPixelRatio(dpr);
		this.scene.fog = new FogExp2(461067, .02);
		this.scene.add(new AmbientLight(1053722, .22));
		this.scene.add(new HemisphereLight(2372672, 658440, .38));
		const moon = new DirectionalLight(10203332, .48);
		moon.position.set(28, 36, -18);
		this.scene.add(moon);
		const moonDisc = new Mesh(new SphereGeometry(3.2, 16, 12), new MeshBasicMaterial({
			color: 14015974,
			fog: false
		}));
		moonDisc.position.set(32, 28, -46);
		this.scene.add(moonDisc);
		this.camera = new PerspectiveCamera(72, 1, .08, 150);
		this.pitch.add(this.camera);
		this.yaw.add(this.pitch);
		this.scene.add(this.yaw);
		this.spot = new SpotLight(16773844, 36, 26, .5, .58, 1.5);
		this.spot.position.set(.18, -.12, .02);
		this.camera.add(this.spot);
		this.spot.target.position.set(0, -.04, -1);
		this.camera.add(this.spot.target);
		this.torch = buildTorch();
		this.torch.position.set(.32, -.3, -.46);
		this.camera.add(this.torch);
		this.buildWorld();
		this.monster = buildMonster();
		this.scene.add(this.monster.group);
		this.load();
		this.resetWorld();
		this.timer.connect(document);
		this.onResize = () => this.resize();
		this.onKeyDown = (e) => {
			if (e.code === "Escape") {
				e.preventDefault();
				if (this.phase === "play") this.setPhase("pause");
				else if (this.phase === "pause") this.resume();
				return;
			}
			this.keys.add(e.code);
		};
		this.onKeyUp = (e) => this.keys.delete(e.code);
		this.onBlur = () => this.keys.clear();
		this.onLock = () => {
			const locked = document.pointerLockElement === this.canvas;
			if (!locked && this.wasLocked && this.phase === "play") this.setPhase("pause");
			this.wasLocked = locked;
		};
		this.onPointerDown = (e) => {
			if (this.phase !== "play") return;
			if (document.pointerLockElement !== this.canvas && !this.touchUi) {
				this.requestLock();
				return;
			}
			if (e.button === 0) this.interactQueued = true;
		};
		this.onPointerMove = (e) => {
			if (document.pointerLockElement !== this.canvas) return;
			this.lookX += e.movementX;
			this.lookY += e.movementY;
		};
		this.onVis = () => {
			if (document.visibilityState === "visible") this.sfx.resume();
		};
		window.addEventListener("resize", this.onResize);
		window.addEventListener("keydown", this.onKeyDown);
		window.addEventListener("keyup", this.onKeyUp);
		window.addEventListener("blur", this.onBlur);
		document.addEventListener("pointerlockchange", this.onLock);
		document.addEventListener("visibilitychange", this.onVis);
		canvas.addEventListener("pointerdown", this.onPointerDown);
		canvas.addEventListener("pointermove", this.onPointerMove);
		canvas.addEventListener("contextmenu", (e) => e.preventDefault());
		this.resize();
		this.renderer.setAnimationLoop(() => this.frame());
		this.attachProbe();
		this.emit(true);
	}
	start() {
		this.emit(true);
	}
	begin() {
		this.sfx.unlock();
		if (this.phase !== "pause") this.resetWorld();
		this.setPhase("play");
		this.requestLock();
	}
	resume() {
		this.sfx.unlock();
		this.setPhase("play");
		this.requestLock();
	}
	setSound(on) {
		this.sound = on;
		this.sfx.setVolume(on ? .8 : 0);
		this.emit(true);
	}
	dispose() {
		this.disposed = true;
		this.renderer.setAnimationLoop(null);
		this.timer.disconnect();
		window.removeEventListener("resize", this.onResize);
		window.removeEventListener("keydown", this.onKeyDown);
		window.removeEventListener("keyup", this.onKeyUp);
		window.removeEventListener("blur", this.onBlur);
		document.removeEventListener("pointerlockchange", this.onLock);
		document.removeEventListener("visibilitychange", this.onVis);
		this.canvas.removeEventListener("pointerdown", this.onPointerDown);
		this.canvas.removeEventListener("pointermove", this.onPointerMove);
		if (window.__controlsTest) delete window.__controlsTest;
		this.renderer.dispose();
	}
	setPhase(p) {
		this.phase = p;
		if (p !== "play" && p !== "scare" && document.pointerLockElement === this.canvas) document.exitPointerLock();
		if (p !== "play") {
			this.keys.clear();
			this.vx = 0;
			this.vz = 0;
		}
		this.emit(true);
	}
	requestLock() {
		if (this.touchUi) return;
		const canvas = this.canvas;
		try {
			const ret = canvas.requestPointerLock({ unadjustedMovement: true });
			if (ret && typeof ret.catch === "function") ret.catch(() => {
				try {
					canvas.requestPointerLock();
				} catch {}
			});
		} catch {
			try {
				canvas.requestPointerLock();
			} catch {}
		}
	}
	resize() {
		const w = this.canvas.clientWidth || window.innerWidth;
		const h = this.canvas.clientHeight || window.innerHeight;
		this.renderer.setSize(w, h, false);
		this.camera.aspect = w / Math.max(1, h);
		this.camera.updateProjectionMatrix();
	}
	frame() {
		if (this.disposed) return;
		this.timer.update();
		const dt = Math.min(this.timer.getDelta(), .05);
		this.clockT += dt;
		this.applyLook();
		if (this.phase === "play") {
			this.elapsed += dt;
			this.readMove(dt);
			this.battery = Math.max(0, this.battery - dt * .02);
			this.updateMonster(dt);
			this.tickWorld(dt);
			this.tickAudio();
			this.updatePrompt();
		} else if (this.phase === "scare") {
			this.scareLeft -= dt;
			this.poseScare();
			if (this.scareLeft <= 0) this.setPhase("dead");
		}
		this.updateLight();
		this.renderer.render(this.scene, this.camera);
		this.emit(false);
	}
	applyLook() {
		const sens = .00215;
		this.yaw.rotation.y -= (this.lookX + this.touch.lookX) * sens;
		this.pitch.rotation.x -= (this.lookY + this.touch.lookY) * sens;
		const lim = Math.PI / 2 - .08;
		this.pitch.rotation.x = clamp(this.pitch.rotation.x, -lim, lim);
		this.lookX = 0;
		this.lookY = 0;
		this.touch.lookX = 0;
		this.touch.lookY = 0;
	}
	held() {
		return this.injected ?? this.keys;
	}
	basis() {
		this.yaw.getWorldDirection(this._fwd);
		this._fwd.negate();
		this._fwd.y = 0;
		if (this._fwd.lengthSq() < 1e-6) this._fwd.set(0, 0, -1);
		else this._fwd.normalize();
		this._right.crossVectors(this._fwd, WORLD_UP);
		if (this._right.lengthSq() < 1e-6) this._right.set(1, 0, 0);
		else this._right.normalize();
	}
	readMove(dt) {
		const held = this.held();
		let ix = 0;
		let iz = 0;
		if (held.has("KeyD") || held.has("ArrowRight")) ix += 1;
		if (held.has("KeyA") || held.has("ArrowLeft")) ix -= 1;
		if (held.has("KeyW") || held.has("ArrowUp")) iz += 1;
		if (held.has("KeyS") || held.has("ArrowDown")) iz -= 1;
		ix += this.touch.moveX;
		iz += this.touch.moveY;
		const ilen = Math.hypot(ix, iz);
		if (ilen > 1) {
			ix /= ilen;
			iz /= ilen;
		}
		this.basis();
		const wishX = this._right.x * ix + this._fwd.x * iz;
		const wishZ = this._right.z * ix + this._fwd.z * iz;
		const moving = ilen > .08;
		const wantSprint = moving && iz > .25 && (held.has("ShiftLeft") || held.has("ShiftRight") || this.touch.sprint);
		let speed = WALK;
		this.sprinting = false;
		if (wantSprint && !this.sprintLock && this.stamina > 0) {
			speed = SPRINT;
			this.sprinting = true;
			this.stamina = Math.max(0, this.stamina - dt / 5.2);
			if (this.stamina <= 0) this.sprintLock = true;
		} else {
			this.stamina = Math.min(1, this.stamina + dt / 3.6);
			if (this.stamina > .32) this.sprintLock = false;
		}
		const targetX = wishX * (moving ? speed : 0);
		const targetZ = wishZ * (moving ? speed : 0);
		const blend = 1 - Math.exp(-dt * 16);
		this.vx += (targetX - this.vx) * blend;
		this.vz += (targetZ - this.vz) * blend;
		const ox = this.x;
		const oz = this.z;
		const dist = Math.hypot(this.vx, this.vz) * dt;
		const n = clamp(Math.ceil(dist / .22), 1, 5);
		const h = dt / n;
		for (let i = 0; i < n; i++) {
			const next = resolve(this.x + this.vx * h, this.z + this.vz * h, PLAYER_R, this.level);
			this.x = next.x;
			this.z = next.z;
		}
		this.yaw.position.x = this.x;
		this.yaw.position.z = this.z;
		this.actualSpeed = dt > 0 ? Math.hypot(this.x - ox, this.z - oz) / dt : 0;
		if (this.actualSpeed > .45) {
			this.stepAcc += this.actualSpeed * dt;
			const stride = this.sprinting ? 2.15 : 1.65;
			if (this.stepAcc > stride) {
				this.stepAcc = 0;
				this.sfx.step();
			}
		}
		const bobOn = this.actualSpeed > .5 ? 1 : 0;
		this.bob += this.actualSpeed * dt;
		this.pitch.position.y = Math.sin(this.bob * 8.2) * .04 * bobOn;
		this.torch.position.y = -.3 + Math.sin(this.bob * 8.2 + .4) * .018 * bobOn;
		const eEdge = (held.has("KeyE") || held.has("KeyF")) && !this.prevInteract;
		this.prevInteract = held.has("KeyE") || held.has("KeyF") || this.touch.interact;
		if (eEdge || this.touch.interact && !this.prevTouchInteract || this.interactQueued) this.tryInteract();
		this.prevTouchInteract = this.touch.interact;
		this.interactQueued = false;
		if (this.touch.interact) {}
	}
	prevTouchInteract = false;
	tryInteract() {
		let best = null;
		let bestD = 1.85;
		for (const it of this.level.items) {
			if (this.collected.has(it.id)) continue;
			const d = Math.hypot(this.x - it.x, this.z - it.z);
			if (d < bestD) {
				bestD = d;
				best = it;
			}
		}
		if (best) {
			this.collected.add(best.id);
			const root = this.itemRoots.get(best.id);
			if (root) root.visible = false;
			if (!best.part) this.battery = Math.min(1, this.battery + .38);
			if (this.battery > .05) this.darkT = 0;
			this.sfx.pickup();
			this.updatePrompt();
			this.emit(true);
			return;
		}
		if (Math.hypot(this.x - this.level.bike.x, this.z - this.level.bike.z) < 2.35 && this.partsLeft() === 0) {
			if (this.best == null || this.elapsed < this.best) this.best = this.elapsed;
			this.save();
			this.sfx.engine();
			this.setPhase("win");
		}
	}
	partsLeft() {
		let n = 0;
		for (const it of this.level.items) if (it.part && !this.collected.has(it.id)) n++;
		return n;
	}
	updateMonster(dt) {
		const got = 4 - this.partsLeft();
		let speed = 4.65;
		if (got >= 2) speed += .4;
		if (got >= 3) speed += .35;
		if (got >= 4) speed += .45;
		if (this.battery <= 0) speed += .65;
		let dx = this.x - this.mx;
		let dz = this.z - this.mz;
		const dist = Math.hypot(dx, dz) || 1;
		dx /= dist;
		dz /= dist;
		let ax = 0;
		let az = 0;
		const trees = this.level.trees;
		for (let i = 0; i < trees.length; i++) {
			const t = trees[i];
			const ox = this.mx - t.x;
			const oz = this.mz - t.z;
			const d = Math.hypot(ox, oz);
			const min = t.r + 1.15;
			if (d < min && d > .001) {
				const k = (min - d) / min;
				ax += ox / d * k;
				az += oz / d * k;
			}
		}
		dx += ax * 1.8;
		dz += az * 1.8;
		const l2 = Math.hypot(dx, dz) || 1;
		dx /= l2;
		dz /= l2;
		const next = resolve(this.mx + dx * speed * dt, this.mz + dz * speed * dt, MONSTER_R, this.level);
		this.mx = next.x;
		this.mz = next.z;
		if (this.battery <= 0) {
			this.darkT += dt;
			if (this.darkT > 16 && dist > 14) {
				this.basis();
				const p = resolve(this.x - this._fwd.x * 11, this.z - this._fwd.z * 11, MONSTER_R, this.level);
				this.mx = p.x;
				this.mz = p.z;
				this.darkT = 7;
			}
		} else this.darkT = 0;
		const nd = Math.hypot(this.x - this.mx, this.z - this.mz);
		this.threat = clamp(1 - (nd - CATCH) / 16, 0, 1);
		this.monster.group.position.set(this.mx, 0, this.mz);
		this.monster.group.rotation.y = Math.atan2(this.x - this.mx, this.z - this.mz);
		this.walkT += dt * speed;
		const swing = Math.sin(this.walkT * 3.1);
		this.monster.legL.rotation.x = swing * .7;
		this.monster.legR.rotation.x = -swing * .7;
		this.monster.armL.rotation.x = -swing * .55;
		this.monster.armR.rotation.x = swing * .55;
		this.monster.head.rotation.z = Math.sin(this.walkT * 1.3) * .08;
		this.monster.head.rotation.x = .12;
		const open = nd < 4 ? 1.8 : 1;
		this.monster.mouth.scale.set(1, open, 1);
		if (nd < CATCH && !losBlocked(this.x, this.z, this.mx, this.mz, this.level.walls)) this.startScare();
	}
	startScare() {
		if (this.phase !== "play") return;
		this.phase = "scare";
		this.scareLeft = .7;
		this.threat = 1;
		this.deaths += 1;
		this.save();
		this.sfx.death();
		this.poseScare();
		this.emit(true);
	}
	poseScare() {
		this.camera.getWorldPosition(this._cam);
		this.camera.getWorldDirection(this._fwd);
		const px = this._cam.x + this._fwd.x * .95;
		const pz = this._cam.z + this._fwd.z * .95;
		this.monster.group.position.set(px, -.42, pz);
		this.monster.group.rotation.y = Math.atan2(this._cam.x - px, this._cam.z - pz);
		this.monster.mouth.scale.set(1.4, 2.6, 1.3);
		this.monster.head.rotation.x = .35;
		this.monster.armL.rotation.x = -1.2;
		this.monster.armR.rotation.x = -1.15;
		const s = Math.sin(this.clockT * 28) * .02;
		this.pitch.position.x = s;
		this.pitch.position.y = Math.cos(this.clockT * 23) * .02;
	}
	tickWorld(dt) {
		for (const root of this.itemRoots.values()) {
			if (!root.visible) continue;
			root.rotation.y += dt * .8;
		}
		const pulse = .45 + Math.sin(this.clockT * 3) * .25;
		for (const m of this.glows) m.emissiveIntensity = pulse;
	}
	tickAudio() {
		const dx = this.mx - this.x;
		const dz = this.mz - this.z;
		const dist = Math.hypot(dx, dz);
		if (dist > 30) return;
		this.basis();
		const len = dist || 1;
		const pan = clamp((dx * this._right.x + dz * this._right.z) / len, -1, 1);
		const k = 1 - dist / 30;
		this.sfx.breath(pan, k);
		if (dist < 10) this.sfx.heart(pan, 1 - dist / 10);
	}
	updatePrompt() {
		const verb = this.touchUi ? "点按拾取" : "按 E 拾取";
		let prompt = "";
		let best = 1.85;
		let name = "";
		for (const it of this.level.items) {
			if (this.collected.has(it.id)) continue;
			const d = Math.hypot(this.x - it.x, this.z - it.z);
			if (d < best) {
				best = d;
				name = it.name;
			}
		}
		if (name) prompt = `${verb} ${name}`;
		else if (Math.hypot(this.x - this.level.bike.x, this.z - this.level.bike.z) < 2.35) prompt = this.partsLeft() === 0 ? this.touchUi ? "点按发动" : "按 E 发动" : "零件还没齐";
		this.prompt = prompt;
		const left = [];
		for (const it of this.level.items) if (it.part && !this.collected.has(it.id)) left.push(`${it.where}·${it.name}`);
		this.objective = left.length ? left.join("   ") : "沿路回到摩托车";
	}
	updateLight() {
		let flick = 1;
		if (this.battery <= 0) flick = .015;
		else if (this.battery < .22) {
			flick = .55 + Math.sin(this.clockT * 34) * .2;
			if (Math.sin(this.clockT * 71) > .82) flick *= .25;
		}
		if (this.phase === "scare") flick = 1.35;
		this.spot.intensity = 34 * flick * (.35 + .65 * clamp(this.battery, 0, 1));
		if (this.phase !== "scare") this.pitch.position.x = 0;
	}
	resetWorld() {
		this.x = this.level.spawn.x;
		this.z = this.level.spawn.z;
		this.vx = 0;
		this.vz = 0;
		this.yaw.position.set(this.x, EYE, this.z);
		this.yaw.rotation.y = 0;
		this.pitch.rotation.x = 0;
		this.pitch.position.set(0, 0, 0);
		this.mx = this.level.monster.x;
		this.mz = this.level.monster.z;
		this.monster.group.position.set(this.mx, 0, this.mz);
		this.battery = 1;
		this.stamina = 1;
		this.sprintLock = false;
		this.elapsed = 0;
		this.darkT = 0;
		this.threat = 0;
		this.collected.clear();
		for (const root of this.itemRoots.values()) root.visible = true;
		this.actualSpeed = 0;
		this.updatePrompt();
	}
	load() {
		try {
			const raw = localStorage.getItem(SAVE_KEY);
			if (!raw) return;
			const s = JSON.parse(raw);
			if (!s || s.v !== 1) return;
			this.best = typeof s.best === "number" ? s.best : null;
			this.deaths = typeof s.deaths === "number" ? s.deaths : 0;
		} catch {}
	}
	save() {
		const data = {
			v: 1,
			best: this.best,
			deaths: this.deaths
		};
		try {
			localStorage.setItem(SAVE_KEY, JSON.stringify(data));
		} catch {}
	}
	partInfos() {
		const out = [];
		for (const it of this.level.items) {
			if (!it.part) continue;
			out.push({
				id: it.id,
				name: it.name,
				where: it.where,
				got: this.collected.has(it.id)
			});
		}
		return out;
	}
	emit(force) {
		const parts = this.partInfos();
		const sig = [
			this.phase,
			this.prompt,
			this.objective,
			Math.round(this.battery * 40),
			Math.round(this.stamina * 20),
			Math.round(this.threat * 20),
			Math.floor(this.elapsed),
			this.best ?? "-",
			this.deaths,
			this.sound ? 1 : 0,
			parts.map((p) => p.got ? "1" : "0").join("")
		].join("|");
		if (!force && sig === this.lastEmit) return;
		this.lastEmit = sig;
		this.onHud({
			phase: this.phase,
			battery: this.battery,
			stamina: this.stamina,
			parts,
			prompt: this.prompt,
			objective: this.objective,
			elapsed: this.elapsed,
			best: this.best,
			deaths: this.deaths,
			threat: this.phase === "scare" ? 1 : this.threat,
			sound: this.sound,
			ready: true
		});
	}
	attachProbe() {
		if (!new URLSearchParams(location.search).has("qa")) return;
		window.__controlsTest = {
			getYaw: () => this.yaw.rotation.y,
			getSpeed: () => this.actualSpeed,
			getPos: () => ({
				x: this.x,
				y: EYE,
				z: this.z
			}),
			setKeys: (codes) => {
				this.injected = codes.length ? new Set(codes) : null;
			},
			setYaw: (y) => {
				this.yaw.rotation.y = y;
			},
			teleport: (x, z) => {
				const p = resolve(x, z, PLAYER_R, this.level);
				this.x = p.x;
				this.z = p.z;
				this.yaw.position.x = p.x;
				this.yaw.position.z = p.z;
			},
			collectAll: () => {
				for (const it of this.level.items) {
					if (!it.part) continue;
					this.collected.add(it.id);
					const root = this.itemRoots.get(it.id);
					if (root) root.visible = false;
				}
				this.updatePrompt();
				this.emit(true);
			}
		};
	}
	buildWorld() {
		const tex = this.paintGround();
		const ground = new Mesh(new PlaneGeometry(164, 164), new MeshStandardMaterial({
			map: tex,
			roughness: 1,
			metalness: 0
		}));
		ground.geometry.rotateX(-Math.PI / 2);
		this.scene.add(ground);
		const roadMat = new MeshStandardMaterial({
			color: 3813928,
			roughness: 1
		});
		const road = this.level.road;
		for (let i = 0; i < road.length - 1; i++) {
			const ax = road[i][0];
			const az = road[i][1];
			const bx = road[i + 1][0];
			const bz = road[i + 1][1];
			const dx = bx - ax;
			const dz = bz - az;
			const mesh = new Mesh(new BoxGeometry(3.5, .04, Math.hypot(dx, dz)), roadMat);
			mesh.position.set((ax + bx) / 2, .03, (az + bz) / 2);
			mesh.rotation.y = Math.atan2(dx, dz);
			this.scene.add(mesh);
		}
		const ravine = new Mesh(new BoxGeometry(36, .05, 9), new MeshStandardMaterial({
			color: 1053720,
			roughness: 1
		}));
		ravine.position.set(12, .045, -49);
		this.scene.add(ravine);
		const plankMat = new MeshStandardMaterial({
			color: 5916210,
			roughness: .9
		});
		for (let i = 0; i < 7; i++) {
			const plank = new Mesh(new BoxGeometry(1.1, .06, 7.2), plankMat);
			plank.position.set(4 + i * 1.5, .08, -49);
			if (i === 3 || i === 5) plank.rotation.y = .4;
			this.scene.add(plank);
		}
		const byColor = /* @__PURE__ */ new Map();
		const matFor = (color) => {
			let m = byColor.get(color);
			if (!m) {
				m = new MeshStandardMaterial({
					color,
					roughness: .92,
					metalness: .02
				});
				byColor.set(color, m);
			}
			return m;
		};
		for (const w of this.level.walls) {
			const sx = Math.max(.05, w.maxX - w.minX);
			const sz = Math.max(.05, w.maxZ - w.minZ);
			const mesh = new Mesh(new BoxGeometry(sx, w.h, sz), matFor(w.color));
			mesh.position.set((w.minX + w.maxX) / 2, w.h / 2, (w.minZ + w.maxZ) / 2);
			this.scene.add(mesh);
		}
		const roof = (x, z, sx, sz, y, color) => {
			const mesh = new Mesh(new BoxGeometry(sx, .16, sz), matFor(color));
			mesh.position.set(x, y, z);
			this.scene.add(mesh);
		};
		roof(11, 2, 7, 5.6, 2.78, 4078648);
		roof(-14, -12, 6.2, 5.4, 2.52, 2759698);
		const rockMat = new MeshStandardMaterial({
			color: 2763046,
			roughness: 1
		});
		for (const rk of this.level.rocks) {
			const mesh = new Mesh(new DodecahedronGeometry(rk.r, 0), rockMat);
			mesh.position.set(rk.x, rk.r * .45, rk.z);
			mesh.rotation.y = rk.x;
			this.scene.add(mesh);
		}
		const trunkGeo = new CylinderGeometry(1, 1.2, 1, 6);
		trunkGeo.translate(0, .5, 0);
		const leafGeo = new ConeGeometry(1, 1, 6);
		leafGeo.translate(0, .45, 0);
		const trunkMat = new MeshStandardMaterial({
			color: 1708556,
			roughness: 1
		});
		const leafMat = new MeshStandardMaterial({
			color: 923152,
			roughness: 1
		});
		const trunks = new InstancedMesh(trunkGeo, trunkMat, this.level.trees.length);
		let leafCount = 0;
		for (const t of this.level.trees) if (t.leaf) leafCount++;
		const leaves = new InstancedMesh(leafGeo, leafMat, Math.max(1, leafCount));
		const dummy = new Object3D();
		let li = 0;
		for (let i = 0; i < this.level.trees.length; i++) {
			const t = this.level.trees[i];
			dummy.position.set(t.x, 0, t.z);
			dummy.scale.set(t.r, t.h, t.r);
			dummy.rotation.set(0, t.x * .2, 0);
			dummy.updateMatrix();
			trunks.setMatrixAt(i, dummy.matrix);
			if (t.leaf) {
				dummy.position.set(t.x, t.h * .62, t.z);
				dummy.scale.set(t.r * 3.4, t.h * .48, t.r * 3.4);
				dummy.rotation.set(0, t.z, 0);
				dummy.updateMatrix();
				leaves.setMatrixAt(li++, dummy.matrix);
			}
		}
		trunks.frustumCulled = false;
		leaves.frustumCulled = false;
		this.scene.add(trunks, leaves);
		this.buildBike();
		for (const it of this.level.items) {
			const { g, mats } = itemMesh(it);
			g.position.set(it.x, 0, it.z);
			this.scene.add(g);
			this.itemRoots.set(it.id, g);
			this.glows.push(...mats);
		}
	}
	buildBike() {
		const g = new Group();
		const red = new MeshStandardMaterial({
			color: 7218208,
			roughness: .55,
			metalness: .25,
			emissive: 2754568,
			emissiveIntensity: .35
		});
		const dark = new MeshStandardMaterial({
			color: 1447446,
			roughness: .45,
			metalness: .5
		});
		const body = new Mesh(new BoxGeometry(.42, .32, 1.25), red);
		body.position.y = .55;
		const seat = new Mesh(new BoxGeometry(.3, .08, .42), dark);
		seat.position.set(0, .76, -.08);
		const wheelGeo = new CylinderGeometry(.28, .28, .1, 12);
		wheelGeo.rotateZ(Math.PI / 2);
		const w1 = new Mesh(wheelGeo, dark);
		w1.position.set(0, .28, .46);
		const w2 = new Mesh(wheelGeo, dark);
		w2.position.set(0, .28, -.48);
		const bar = new Mesh(new BoxGeometry(.46, .04, .04), dark);
		bar.position.set(0, .92, .42);
		const tail = new Mesh(new BoxGeometry(.16, .07, .04), new MeshStandardMaterial({
			color: 16724760,
			emissive: 16720392,
			emissiveIntensity: .9
		}));
		tail.position.set(0, .62, -.64);
		g.add(body, seat, w1, w2, bar, tail);
		g.position.set(this.level.bike.x, 0, this.level.bike.z);
		this.scene.add(g);
	}
	paintGround() {
		const size = 768;
		const canvas = document.createElement("canvas");
		canvas.width = size;
		canvas.height = size;
		const ctx = canvas.getContext("2d");
		if (!ctx) return new CanvasTexture(canvas);
		const img = ctx.createImageData(size, size);
		const data = img.data;
		const span = 164;
		for (let y = 0; y < size; y++) {
			const wz = y / size * span - span / 2;
			for (let x = 0; x < size; x++) {
				const wx = x / size * span - span / 2;
				const n = Math.sin(wx * .7 + wz * 1.3) * .5 + .5;
				let r = 14 + n * 16;
				let g = 18 + n * 12;
				let b = 13 + n * 8;
				if (wz < -43 && wz > -55 && wx > -6 && wx < 32) {
					r *= .38;
					g *= .42;
					b *= .5;
				}
				const i = (y * size + x) * 4;
				data[i] = r;
				data[i + 1] = g;
				data[i + 2] = b;
				data[i + 3] = 255;
			}
		}
		ctx.putImageData(img, 0, 0);
		const tex = new CanvasTexture(canvas);
		tex.colorSpace = SRGBColorSpace;
		tex.anisotropy = 4;
		return tex;
	}
};
//#endregion
export { ForestGame };

import { i as __toESM } from "../_runtime.mjs";
import { G as require_jsx_runtime, K as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BGwLNA7_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var Sfx = class {
	ctx = null;
	master = null;
	bus = null;
	noise = null;
	volume = .8;
	lastBreath = 0;
	lastHeart = 0;
	unlock() {
		const Ctx = window.AudioContext || window.webkitAudioContext;
		if (!Ctx) return;
		if (!this.ctx) {
			this.ctx = new Ctx({ latencyHint: "interactive" });
			this.master = this.ctx.createGain();
			this.bus = this.ctx.createGain();
			this.bus.connect(this.master);
			this.master.connect(this.ctx.destination);
			this.applyVolume();
			this.makeNoise();
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
	}
	resume() {
		if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
	}
	setVolume(v) {
		this.volume = Math.min(1, Math.max(0, v));
		this.applyVolume();
	}
	applyVolume() {
		if (!this.master || !this.ctx) return;
		const g = this.volume * this.volume;
		this.master.gain.setTargetAtTime(g, this.ctx.currentTime, .02);
	}
	makeNoise() {
		if (!this.ctx) return;
		const len = this.ctx.sampleRate;
		const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
		const data = buf.getChannelData(0);
		for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
		this.noise = buf;
	}
	burst(o) {
		if (!this.ctx || !this.noise || !this.bus || this.volume <= .001) return;
		const ctx = this.ctx;
		const src = ctx.createBufferSource();
		src.buffer = this.noise;
		src.playbackRate.value = o.rate ?? 1;
		const filter = ctx.createBiquadFilter();
		filter.type = o.filter;
		filter.frequency.value = o.freq;
		filter.Q.value = o.q;
		const gain = ctx.createGain();
		const panner = ctx.createStereoPanner();
		panner.pan.value = Math.max(-1, Math.min(1, o.pan));
		src.connect(filter);
		filter.connect(gain);
		gain.connect(panner);
		panner.connect(this.bus);
		const t = ctx.currentTime;
		const peak = Math.max(.001, o.gain);
		gain.gain.setValueAtTime(1e-4, t);
		gain.gain.exponentialRampToValueAtTime(peak, t + .018);
		gain.gain.exponentialRampToValueAtTime(1e-4, t + o.dur);
		src.start(t);
		src.stop(t + o.dur + .03);
		src.onended = () => {
			src.disconnect();
			filter.disconnect();
			gain.disconnect();
			panner.disconnect();
		};
	}
	step() {
		this.burst({
			freq: 180 + Math.random() * 80,
			q: .7,
			dur: .07,
			gain: .07 + Math.random() * .03,
			pan: (Math.random() - .5) * .3,
			filter: "bandpass",
			rate: .8 + Math.random() * .4
		});
	}
	breath(pan, intensity) {
		if (!this.ctx) return;
		const now = this.ctx.currentTime;
		const gap = .7 - intensity * .28;
		if (now - this.lastBreath < gap) return;
		this.lastBreath = now;
		this.burst({
			freq: 120 + (1 - intensity) * 40,
			q: .6,
			dur: .32 + intensity * .18,
			gain: .03 + intensity * .2,
			pan,
			filter: "lowpass",
			rate: .55 + Math.random() * .2
		});
	}
	heart(pan, intensity) {
		if (!this.ctx || !this.bus || this.volume <= .001) return;
		const now = this.ctx.currentTime;
		const gap = .72 - intensity * .38;
		if (now - this.lastHeart < gap) return;
		this.lastHeart = now;
		const osc = this.ctx.createOscillator();
		osc.type = "sine";
		osc.frequency.setValueAtTime(62, now);
		osc.frequency.exponentialRampToValueAtTime(34, now + .12);
		const gain = this.ctx.createGain();
		const panner = this.ctx.createStereoPanner();
		panner.pan.value = Math.max(-1, Math.min(1, pan));
		osc.connect(gain);
		gain.connect(panner);
		panner.connect(this.bus);
		const peak = .08 + intensity * .16;
		gain.gain.setValueAtTime(1e-4, now);
		gain.gain.exponentialRampToValueAtTime(peak, now + .012);
		gain.gain.exponentialRampToValueAtTime(1e-4, now + .15);
		osc.start(now);
		osc.stop(now + .17);
		osc.onended = () => {
			osc.disconnect();
			gain.disconnect();
			panner.disconnect();
		};
	}
	pickup() {
		this.burst({
			freq: 1400,
			q: 2,
			dur: .05,
			gain: .08,
			pan: 0,
			filter: "bandpass",
			rate: 1.2
		});
		window.setTimeout(() => {
			this.burst({
				freq: 900,
				q: 1.4,
				dur: .06,
				gain: .05,
				pan: 0,
				filter: "bandpass"
			});
		}, 70);
	}
	death() {
		this.burst({
			freq: 240,
			q: .4,
			dur: .55,
			gain: .35,
			pan: 0,
			filter: "lowpass",
			rate: .4
		});
	}
	engine() {
		this.burst({
			freq: 90,
			q: 1.6,
			dur: 1.1,
			gain: .16,
			pan: 0,
			filter: "bandpass",
			rate: .35
		});
	}
};
var singleton = null;
function primeAudio() {
	if (!singleton) singleton = new Sfx();
	singleton.unlock();
	return singleton;
}
function getSfx() {
	if (!singleton) singleton = new Sfx();
	return singleton;
}
var emptyHud = () => ({
	phase: "menu",
	battery: 1,
	stamina: 1,
	parts: [
		{
			id: "spark",
			name: "火花塞",
			where: "水泥房",
			got: false
		},
		{
			id: "oil",
			name: "机油",
			where: "木屋",
			got: false
		},
		{
			id: "pack",
			name: "电瓶",
			where: "断桥",
			got: false
		},
		{
			id: "tire",
			name: "轮胎",
			where: "迷宫",
			got: false
		}
	],
	prompt: "",
	objective: "水泥房·火花塞   木屋·机油   断桥·电瓶   迷宫·轮胎",
	elapsed: 0,
	best: null,
	deaths: 0,
	threat: 0,
	sound: true,
	ready: false
});
function fmt(sec) {
	const s = Math.max(0, Math.floor(sec));
	return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}
function GameView() {
	const canvasRef = (0, import_react.useRef)(null);
	const touch = (0, import_react.useRef)({
		moveX: 0,
		moveY: 0,
		lookX: 0,
		lookY: 0,
		sprint: false,
		interact: false
	}).current;
	const engineRef = (0, import_react.useRef)(null);
	const pending = (0, import_react.useRef)(false);
	const [hud, setHud] = (0, import_react.useState)(emptyHud);
	const [touchUi, setTouchUi] = (0, import_react.useState)(false);
	const [locked, setLocked] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const apply = () => {
			const coarse = window.matchMedia("(pointer: coarse)").matches || window.innerWidth < 860;
			setTouchUi(coarse);
			engineRef.current && (engineRef.current.touchUi = coarse);
		};
		apply();
		window.addEventListener("resize", apply);
		const onLock = () => setLocked(document.pointerLockElement != null);
		document.addEventListener("pointerlockchange", onLock);
		let dead = false;
		let game = null;
		import("./engine-BupMWj5D.mjs").then(({ ForestGame }) => {
			if (dead || !canvasRef.current) return;
			game = new ForestGame(canvasRef.current, touch, setHud);
			game.touchUi = window.matchMedia("(pointer: coarse)").matches || window.innerWidth < 860;
			engineRef.current = game;
			game.start();
			if (pending.current) {
				pending.current = false;
				game.begin();
			}
		});
		return () => {
			dead = true;
			window.removeEventListener("resize", apply);
			document.removeEventListener("pointerlockchange", onLock);
			game?.dispose();
			engineRef.current = null;
		};
	}, [touch]);
	function onStart() {
		primeAudio();
		if (!engineRef.current) {
			pending.current = true;
			return;
		}
		engineRef.current.begin();
	}
	function onResume() {
		primeAudio();
		engineRef.current?.resume();
	}
	function toggleSound() {
		primeAudio();
		engineRef.current?.setSound(!hud.sound);
	}
	const playing = hud.phase === "play" || hud.phase === "scare";
	const got = hud.parts.filter((p) => p.got).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full select-none overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 h-full w-full touch-none"
			}),
			playing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grain",
				"aria-hidden": "true"
			}),
			playing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "threat",
				style: { opacity: Math.min(.85, hud.threat) },
				"aria-hidden": "true"
			}),
			playing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-none absolute top-4 right-4 left-4 flex items-start justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-36",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-1 flex items-center justify-between text-xs text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "手电" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: Math.round(hud.battery * 100) })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-1.5 bg-line",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: hud.battery < .2 ? "h-full bg-bloodhot" : "h-full bg-paper",
									style: { width: `${Math.round(hud.battery * 100)}%` }
								})
							}),
							hud.battery < .2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-bloodhot",
								children: "快没电了"
							}),
							hud.stamina < .98 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 h-1 bg-line",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-moon",
									style: { width: `${Math.round(hud.stamina * 100)}%` }
								})
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-lg text-paper",
							children: [got, "/4"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: fmt(hud.elapsed)
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute top-1/2 left-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-paper" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-none absolute right-4 bottom-28 left-4 text-center sm:bottom-10",
					children: [hud.prompt && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg text-paper",
						children: hud.prompt
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: hud.objective
					})]
				}),
				!touchUi && !locked && hud.phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pointer-events-none absolute bottom-6 left-1/2 -translate-x-1/2 text-xs text-muted",
					children: "点击画面转动视角"
				})
			] }),
			touchUi && hud.phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchControls, { touch }),
			hud.phase === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "absolute inset-0 flex flex-col justify-end bg-bg px-6 pt-16 pb-8 sm:px-12 sm:pb-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-lg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-blood",
							children: "夜 · 林间近道"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-display text-6xl text-blood sm:text-8xl",
							children: "近路"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-md text-base leading-relaxed text-fg",
							children: "摩托车在林子里熄了火。火花塞、机油、电瓶、轮胎，找齐才能发动。从你走进来的那一刻，就有东西在跟着。"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted",
							children: "水泥房在路东，木屋在路西，电瓶在南边断桥，轮胎在铁丝迷宫尽头。它比走路快，只有跑起来才拉得开。手电会没电，地上有电池。碰到它，就结束。"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							id: "start-btn",
							onClick: onStart,
							className: "mt-6 bg-blood px-8 py-3 font-display text-lg text-paper",
							children: "进入森林"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs leading-relaxed text-muted",
							children: "WASD 移动 · 鼠标环视 · Shift 奔跑 · E 拾取 · ESC 暂停"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: "没有背景音乐。只有脚步，和它的呼吸。"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: toggleSound,
							className: "mt-4 text-sm text-moon",
							children: ["音效 ", hud.sound ? "开" : "关"]
						})
					]
				})
			}),
			hud.phase === "pause" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "absolute inset-0 flex flex-col justify-end bg-bg/90 px-6 pt-16 pb-8 sm:px-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-lg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl text-paper",
							children: "停住"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted",
							children: "它没有停。零件还在原来的地方：水泥房、木屋、断桥、迷宫。回到北边的摩托车。"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-fg",
							children: hud.objective
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onResume,
							className: "mt-6 bg-blood px-8 py-3 font-display text-lg text-paper",
							children: "继续走"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: toggleSound,
							className: "mt-4 block text-sm text-moon",
							children: ["音效 ", hud.sound ? "开" : "关"]
						})
					]
				})
			}),
			hud.phase === "dead" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "absolute inset-0 flex flex-col justify-between bg-bg px-6 py-10 sm:px-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm tracking-widest text-blood",
						children: "寻人启事"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-lg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-4xl text-paper sm:text-5xl",
								children: "你没有回来"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 leading-relaxed text-muted",
								children: [
									"最后出现在林间近道。走了 ",
									fmt(hud.elapsed),
									"。这是第 ",
									hud.deaths,
									" 次。"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "零件会回到原处。它也会。"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onStart,
						className: "w-fit bg-blood px-8 py-3 font-display text-lg text-paper",
						children: "再走一次"
					})
				]
			}),
			hud.phase === "win" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "absolute inset-0 flex flex-col justify-between bg-bg px-6 py-10 sm:px-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm tracking-widest text-moon",
						children: "引擎响了"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-lg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-4xl text-paper sm:text-5xl",
								children: "你没有回头"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 leading-relaxed text-fg",
								children: ["用时 ", fmt(hud.elapsed)]
							}),
							hud.best != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: ["最短 ", fmt(hud.best)]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onStart,
						className: "w-fit bg-blood px-8 py-3 font-display text-lg text-paper",
						children: "再走一次"
					})
				]
			})
		]
	});
}
function TouchControls({ touch }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 touch-none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LookPad, { touch }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stick, { touch }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute right-4 bottom-6 z-10 flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoldButton, {
					label: "奔跑",
					onChange: (v) => touch.sprint = v
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoldButton, {
					label: "拾取",
					onChange: (v) => touch.interact = v
				})]
			})
		]
	});
}
function HoldButton({ label, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "h-14 min-w-14 border border-line bg-surface px-4 text-sm text-paper",
		onPointerDown: (e) => {
			e.stopPropagation();
			e.currentTarget.setPointerCapture(e.pointerId);
			onChange(true);
		},
		onPointerUp: (e) => {
			e.stopPropagation();
			onChange(false);
		},
		onPointerCancel: () => onChange(false),
		children: label
	});
}
function Stick({ touch }) {
	const base = (0, import_react.useRef)(null);
	const [knob, setKnob] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	function setFrom(clientX, clientY) {
		const rect = base.current?.getBoundingClientRect();
		if (!rect) return;
		const cx = rect.left + rect.width / 2;
		const cy = rect.top + rect.height / 2;
		let dx = clientX - cx;
		let dy = clientY - cy;
		const max = rect.width * .36;
		const len = Math.hypot(dx, dy) || 1;
		const cl = Math.min(len, max);
		dx = dx / len * cl;
		dy = dy / len * cl;
		touch.moveX = dx / max;
		touch.moveY = -dy / max;
		setKnob({
			x: dx,
			y: dy
		});
	}
	function end() {
		touch.moveX = 0;
		touch.moveY = 0;
		setKnob({
			x: 0,
			y: 0
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: base,
		className: "absolute bottom-6 left-4 z-10 h-32 w-32 rounded-full border border-line bg-surface/80",
		onPointerDown: (e) => {
			e.stopPropagation();
			e.currentTarget.setPointerCapture(e.pointerId);
			setFrom(e.clientX, e.clientY);
		},
		onPointerMove: (e) => {
			if (e.currentTarget.hasPointerCapture(e.pointerId)) setFrom(e.clientX, e.clientY);
		},
		onPointerUp: end,
		onPointerCancel: end,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute top-1/2 left-1/2 h-12 w-12 rounded-full bg-paper",
			style: { transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }
		})
	});
}
function LookPad({ touch }) {
	const last = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-y-0 right-0 w-1/2",
		onPointerDown: (e) => {
			if (e.target.closest("button")) return;
			e.currentTarget.setPointerCapture(e.pointerId);
			last.current = {
				x: e.clientX,
				y: e.clientY
			};
		},
		onPointerMove: (e) => {
			if (!last.current) return;
			touch.lookX += e.clientX - last.current.x;
			touch.lookY += e.clientY - last.current.y;
			last.current = {
				x: e.clientX,
				y: e.clientY
			};
		},
		onPointerUp: () => {
			last.current = null;
		},
		onPointerCancel: () => {
			last.current = null;
		}
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => SplitComponent });
var SplitComponent = GameView;
//#endregion
export { getSfx as n, routes_exports as t };
